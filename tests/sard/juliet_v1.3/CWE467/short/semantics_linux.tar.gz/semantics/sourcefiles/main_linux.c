#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE467_Use_of_sizeof_on_Pointer_Type__short_01_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_02_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_03_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_04_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_05_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_06_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_07_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_08_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_09_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_10_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_11_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_12_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_13_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_14_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_15_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_16_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_17_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_18_good();

	CWE467_Use_of_sizeof_on_Pointer_Type__short_01_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_02_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_03_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_04_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_05_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_06_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_07_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_08_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_09_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_10_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_11_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_12_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_13_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_14_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_15_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_16_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_17_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__short_18_bad();

	return 0;
}
