#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE476_NULL_Pointer_Dereference__char_01_good();
	CWE476_NULL_Pointer_Dereference__char_02_good();
	CWE476_NULL_Pointer_Dereference__char_03_good();
	CWE476_NULL_Pointer_Dereference__char_04_good();
	CWE476_NULL_Pointer_Dereference__char_05_good();
	CWE476_NULL_Pointer_Dereference__char_06_good();
	CWE476_NULL_Pointer_Dereference__char_07_good();
	CWE476_NULL_Pointer_Dereference__char_08_good();
	CWE476_NULL_Pointer_Dereference__char_09_good();
	CWE476_NULL_Pointer_Dereference__char_10_good();
	CWE476_NULL_Pointer_Dereference__char_11_good();
	CWE476_NULL_Pointer_Dereference__char_12_good();
	CWE476_NULL_Pointer_Dereference__char_13_good();
	CWE476_NULL_Pointer_Dereference__char_14_good();
	CWE476_NULL_Pointer_Dereference__char_15_good();
	CWE476_NULL_Pointer_Dereference__char_16_good();
	CWE476_NULL_Pointer_Dereference__char_17_good();
	CWE476_NULL_Pointer_Dereference__char_18_good();
	CWE476_NULL_Pointer_Dereference__char_21_good();
	CWE476_NULL_Pointer_Dereference__char_22_good();
	CWE476_NULL_Pointer_Dereference__char_31_good();
	CWE476_NULL_Pointer_Dereference__char_32_good();
	CWE476_NULL_Pointer_Dereference__char_34_good();
	CWE476_NULL_Pointer_Dereference__char_41_good();
	CWE476_NULL_Pointer_Dereference__char_44_good();
	CWE476_NULL_Pointer_Dereference__char_45_good();
	CWE476_NULL_Pointer_Dereference__char_51_good();
	CWE476_NULL_Pointer_Dereference__char_52_good();
	CWE476_NULL_Pointer_Dereference__char_53_good();
	CWE476_NULL_Pointer_Dereference__char_54_good();
	CWE476_NULL_Pointer_Dereference__char_63_good();
	CWE476_NULL_Pointer_Dereference__char_64_good();
	CWE476_NULL_Pointer_Dereference__char_65_good();
	CWE476_NULL_Pointer_Dereference__char_66_good();
	CWE476_NULL_Pointer_Dereference__char_67_good();
	CWE476_NULL_Pointer_Dereference__char_68_good();

	CWE476_NULL_Pointer_Dereference__char_01_bad();
	CWE476_NULL_Pointer_Dereference__char_02_bad();
	CWE476_NULL_Pointer_Dereference__char_03_bad();
	CWE476_NULL_Pointer_Dereference__char_04_bad();
	CWE476_NULL_Pointer_Dereference__char_05_bad();
	CWE476_NULL_Pointer_Dereference__char_06_bad();
	CWE476_NULL_Pointer_Dereference__char_07_bad();
	CWE476_NULL_Pointer_Dereference__char_08_bad();
	CWE476_NULL_Pointer_Dereference__char_09_bad();
	CWE476_NULL_Pointer_Dereference__char_10_bad();
	CWE476_NULL_Pointer_Dereference__char_11_bad();
	CWE476_NULL_Pointer_Dereference__char_12_bad();
	CWE476_NULL_Pointer_Dereference__char_13_bad();
	CWE476_NULL_Pointer_Dereference__char_14_bad();
	CWE476_NULL_Pointer_Dereference__char_15_bad();
	CWE476_NULL_Pointer_Dereference__char_16_bad();
	CWE476_NULL_Pointer_Dereference__char_17_bad();
	CWE476_NULL_Pointer_Dereference__char_18_bad();
	CWE476_NULL_Pointer_Dereference__char_21_bad();
	CWE476_NULL_Pointer_Dereference__char_22_bad();
	CWE476_NULL_Pointer_Dereference__char_31_bad();
	CWE476_NULL_Pointer_Dereference__char_32_bad();
	CWE476_NULL_Pointer_Dereference__char_34_bad();
	CWE476_NULL_Pointer_Dereference__char_41_bad();
	CWE476_NULL_Pointer_Dereference__char_44_bad();
	CWE476_NULL_Pointer_Dereference__char_45_bad();
	CWE476_NULL_Pointer_Dereference__char_51_bad();
	CWE476_NULL_Pointer_Dereference__char_52_bad();
	CWE476_NULL_Pointer_Dereference__char_53_bad();
	CWE476_NULL_Pointer_Dereference__char_54_bad();
	CWE476_NULL_Pointer_Dereference__char_63_bad();
	CWE476_NULL_Pointer_Dereference__char_64_bad();
	CWE476_NULL_Pointer_Dereference__char_65_bad();
	CWE476_NULL_Pointer_Dereference__char_66_bad();
	CWE476_NULL_Pointer_Dereference__char_67_bad();
	CWE476_NULL_Pointer_Dereference__char_68_bad();

	return 0;
}
