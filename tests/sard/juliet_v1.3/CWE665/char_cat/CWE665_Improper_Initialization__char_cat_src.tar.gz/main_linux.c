#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE665_Improper_Initialization__char_cat_01_good();
	CWE665_Improper_Initialization__char_cat_02_good();
	CWE665_Improper_Initialization__char_cat_03_good();
	CWE665_Improper_Initialization__char_cat_04_good();
	CWE665_Improper_Initialization__char_cat_05_good();
	CWE665_Improper_Initialization__char_cat_06_good();
	CWE665_Improper_Initialization__char_cat_07_good();
	CWE665_Improper_Initialization__char_cat_08_good();
	CWE665_Improper_Initialization__char_cat_09_good();
	CWE665_Improper_Initialization__char_cat_10_good();
	CWE665_Improper_Initialization__char_cat_11_good();
	CWE665_Improper_Initialization__char_cat_12_good();
	CWE665_Improper_Initialization__char_cat_13_good();
	CWE665_Improper_Initialization__char_cat_14_good();
	CWE665_Improper_Initialization__char_cat_15_good();
	CWE665_Improper_Initialization__char_cat_16_good();
	CWE665_Improper_Initialization__char_cat_17_good();
	CWE665_Improper_Initialization__char_cat_18_good();
	CWE665_Improper_Initialization__char_cat_21_good();
	CWE665_Improper_Initialization__char_cat_22_good();
	CWE665_Improper_Initialization__char_cat_31_good();
	CWE665_Improper_Initialization__char_cat_32_good();
	CWE665_Improper_Initialization__char_cat_34_good();
	CWE665_Improper_Initialization__char_cat_41_good();
	CWE665_Improper_Initialization__char_cat_42_good();
	CWE665_Improper_Initialization__char_cat_44_good();
	CWE665_Improper_Initialization__char_cat_45_good();
	CWE665_Improper_Initialization__char_cat_51_good();
	CWE665_Improper_Initialization__char_cat_52_good();
	CWE665_Improper_Initialization__char_cat_53_good();
	CWE665_Improper_Initialization__char_cat_54_good();
	CWE665_Improper_Initialization__char_cat_61_good();
	CWE665_Improper_Initialization__char_cat_63_good();
	CWE665_Improper_Initialization__char_cat_64_good();
	CWE665_Improper_Initialization__char_cat_65_good();
	CWE665_Improper_Initialization__char_cat_66_good();
	CWE665_Improper_Initialization__char_cat_67_good();
	CWE665_Improper_Initialization__char_cat_68_good();

	CWE665_Improper_Initialization__char_cat_01_bad();
	CWE665_Improper_Initialization__char_cat_02_bad();
	CWE665_Improper_Initialization__char_cat_03_bad();
	CWE665_Improper_Initialization__char_cat_04_bad();
	CWE665_Improper_Initialization__char_cat_05_bad();
	CWE665_Improper_Initialization__char_cat_06_bad();
	CWE665_Improper_Initialization__char_cat_07_bad();
	CWE665_Improper_Initialization__char_cat_08_bad();
	CWE665_Improper_Initialization__char_cat_09_bad();
	CWE665_Improper_Initialization__char_cat_10_bad();
	CWE665_Improper_Initialization__char_cat_11_bad();
	CWE665_Improper_Initialization__char_cat_12_bad();
	CWE665_Improper_Initialization__char_cat_13_bad();
	CWE665_Improper_Initialization__char_cat_14_bad();
	CWE665_Improper_Initialization__char_cat_15_bad();
	CWE665_Improper_Initialization__char_cat_16_bad();
	CWE665_Improper_Initialization__char_cat_17_bad();
	CWE665_Improper_Initialization__char_cat_18_bad();
	CWE665_Improper_Initialization__char_cat_21_bad();
	CWE665_Improper_Initialization__char_cat_22_bad();
	CWE665_Improper_Initialization__char_cat_31_bad();
	CWE665_Improper_Initialization__char_cat_32_bad();
	CWE665_Improper_Initialization__char_cat_34_bad();
	CWE665_Improper_Initialization__char_cat_41_bad();
	CWE665_Improper_Initialization__char_cat_42_bad();
	CWE665_Improper_Initialization__char_cat_44_bad();
	CWE665_Improper_Initialization__char_cat_45_bad();
	CWE665_Improper_Initialization__char_cat_51_bad();
	CWE665_Improper_Initialization__char_cat_52_bad();
	CWE665_Improper_Initialization__char_cat_53_bad();
	CWE665_Improper_Initialization__char_cat_54_bad();
	CWE665_Improper_Initialization__char_cat_61_bad();
	CWE665_Improper_Initialization__char_cat_63_bad();
	CWE665_Improper_Initialization__char_cat_64_bad();
	CWE665_Improper_Initialization__char_cat_65_bad();
	CWE665_Improper_Initialization__char_cat_66_bad();
	CWE665_Improper_Initialization__char_cat_67_bad();
	CWE665_Improper_Initialization__char_cat_68_bad();

	return 0;
}
