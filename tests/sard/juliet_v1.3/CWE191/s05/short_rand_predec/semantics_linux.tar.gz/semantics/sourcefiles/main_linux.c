#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE191_Integer_Underflow__short_rand_predec_01_good();
	CWE191_Integer_Underflow__short_rand_predec_02_good();
	CWE191_Integer_Underflow__short_rand_predec_03_good();
	CWE191_Integer_Underflow__short_rand_predec_04_good();
	CWE191_Integer_Underflow__short_rand_predec_05_good();
	CWE191_Integer_Underflow__short_rand_predec_06_good();
	CWE191_Integer_Underflow__short_rand_predec_07_good();
	CWE191_Integer_Underflow__short_rand_predec_08_good();
	CWE191_Integer_Underflow__short_rand_predec_09_good();
	CWE191_Integer_Underflow__short_rand_predec_10_good();
	CWE191_Integer_Underflow__short_rand_predec_11_good();
	CWE191_Integer_Underflow__short_rand_predec_12_good();
	CWE191_Integer_Underflow__short_rand_predec_13_good();
	CWE191_Integer_Underflow__short_rand_predec_14_good();
	CWE191_Integer_Underflow__short_rand_predec_15_good();
	CWE191_Integer_Underflow__short_rand_predec_16_good();
	CWE191_Integer_Underflow__short_rand_predec_17_good();
	CWE191_Integer_Underflow__short_rand_predec_18_good();
	CWE191_Integer_Underflow__short_rand_predec_21_good();
	CWE191_Integer_Underflow__short_rand_predec_22_good();
	CWE191_Integer_Underflow__short_rand_predec_31_good();
	CWE191_Integer_Underflow__short_rand_predec_32_good();
	CWE191_Integer_Underflow__short_rand_predec_34_good();
	CWE191_Integer_Underflow__short_rand_predec_41_good();
	CWE191_Integer_Underflow__short_rand_predec_42_good();
	CWE191_Integer_Underflow__short_rand_predec_44_good();
	CWE191_Integer_Underflow__short_rand_predec_45_good();
	CWE191_Integer_Underflow__short_rand_predec_51_good();
	CWE191_Integer_Underflow__short_rand_predec_52_good();
	CWE191_Integer_Underflow__short_rand_predec_53_good();
	CWE191_Integer_Underflow__short_rand_predec_54_good();
	CWE191_Integer_Underflow__short_rand_predec_61_good();
	CWE191_Integer_Underflow__short_rand_predec_63_good();
	CWE191_Integer_Underflow__short_rand_predec_64_good();
	CWE191_Integer_Underflow__short_rand_predec_65_good();
	CWE191_Integer_Underflow__short_rand_predec_66_good();
	CWE191_Integer_Underflow__short_rand_predec_67_good();
	CWE191_Integer_Underflow__short_rand_predec_68_good();

	CWE191_Integer_Underflow__short_rand_predec_01_bad();
	CWE191_Integer_Underflow__short_rand_predec_02_bad();
	CWE191_Integer_Underflow__short_rand_predec_03_bad();
	CWE191_Integer_Underflow__short_rand_predec_04_bad();
	CWE191_Integer_Underflow__short_rand_predec_05_bad();
	CWE191_Integer_Underflow__short_rand_predec_06_bad();
	CWE191_Integer_Underflow__short_rand_predec_07_bad();
	CWE191_Integer_Underflow__short_rand_predec_08_bad();
	CWE191_Integer_Underflow__short_rand_predec_09_bad();
	CWE191_Integer_Underflow__short_rand_predec_10_bad();
	CWE191_Integer_Underflow__short_rand_predec_11_bad();
	CWE191_Integer_Underflow__short_rand_predec_12_bad();
	CWE191_Integer_Underflow__short_rand_predec_13_bad();
	CWE191_Integer_Underflow__short_rand_predec_14_bad();
	CWE191_Integer_Underflow__short_rand_predec_15_bad();
	CWE191_Integer_Underflow__short_rand_predec_16_bad();
	CWE191_Integer_Underflow__short_rand_predec_17_bad();
	CWE191_Integer_Underflow__short_rand_predec_18_bad();
	CWE191_Integer_Underflow__short_rand_predec_21_bad();
	CWE191_Integer_Underflow__short_rand_predec_22_bad();
	CWE191_Integer_Underflow__short_rand_predec_31_bad();
	CWE191_Integer_Underflow__short_rand_predec_32_bad();
	CWE191_Integer_Underflow__short_rand_predec_34_bad();
	CWE191_Integer_Underflow__short_rand_predec_41_bad();
	CWE191_Integer_Underflow__short_rand_predec_42_bad();
	CWE191_Integer_Underflow__short_rand_predec_44_bad();
	CWE191_Integer_Underflow__short_rand_predec_45_bad();
	CWE191_Integer_Underflow__short_rand_predec_51_bad();
	CWE191_Integer_Underflow__short_rand_predec_52_bad();
	CWE191_Integer_Underflow__short_rand_predec_53_bad();
	CWE191_Integer_Underflow__short_rand_predec_54_bad();
	CWE191_Integer_Underflow__short_rand_predec_61_bad();
	CWE191_Integer_Underflow__short_rand_predec_63_bad();
	CWE191_Integer_Underflow__short_rand_predec_64_bad();
	CWE191_Integer_Underflow__short_rand_predec_65_bad();
	CWE191_Integer_Underflow__short_rand_predec_66_bad();
	CWE191_Integer_Underflow__short_rand_predec_67_bad();
	CWE191_Integer_Underflow__short_rand_predec_68_bad();

	return 0;
}
