#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__char_alloca_loop_01_good();
	CWE126_Buffer_Overread__char_alloca_loop_02_good();
	CWE126_Buffer_Overread__char_alloca_loop_03_good();
	CWE126_Buffer_Overread__char_alloca_loop_04_good();
	CWE126_Buffer_Overread__char_alloca_loop_05_good();
	CWE126_Buffer_Overread__char_alloca_loop_06_good();
	CWE126_Buffer_Overread__char_alloca_loop_07_good();
	CWE126_Buffer_Overread__char_alloca_loop_08_good();
	CWE126_Buffer_Overread__char_alloca_loop_09_good();
	CWE126_Buffer_Overread__char_alloca_loop_10_good();
	CWE126_Buffer_Overread__char_alloca_loop_11_good();
	CWE126_Buffer_Overread__char_alloca_loop_12_good();
	CWE126_Buffer_Overread__char_alloca_loop_13_good();
	CWE126_Buffer_Overread__char_alloca_loop_14_good();
	CWE126_Buffer_Overread__char_alloca_loop_15_good();
	CWE126_Buffer_Overread__char_alloca_loop_16_good();
	CWE126_Buffer_Overread__char_alloca_loop_17_good();
	CWE126_Buffer_Overread__char_alloca_loop_18_good();
	CWE126_Buffer_Overread__char_alloca_loop_31_good();
	CWE126_Buffer_Overread__char_alloca_loop_32_good();
	CWE126_Buffer_Overread__char_alloca_loop_34_good();
	CWE126_Buffer_Overread__char_alloca_loop_41_good();
	CWE126_Buffer_Overread__char_alloca_loop_44_good();
	CWE126_Buffer_Overread__char_alloca_loop_45_good();
	CWE126_Buffer_Overread__char_alloca_loop_51_good();
	CWE126_Buffer_Overread__char_alloca_loop_52_good();
	CWE126_Buffer_Overread__char_alloca_loop_53_good();
	CWE126_Buffer_Overread__char_alloca_loop_54_good();
	CWE126_Buffer_Overread__char_alloca_loop_63_good();
	CWE126_Buffer_Overread__char_alloca_loop_64_good();
	CWE126_Buffer_Overread__char_alloca_loop_65_good();
	CWE126_Buffer_Overread__char_alloca_loop_66_good();
	CWE126_Buffer_Overread__char_alloca_loop_67_good();
	CWE126_Buffer_Overread__char_alloca_loop_68_good();

	CWE126_Buffer_Overread__char_alloca_loop_01_bad();
	CWE126_Buffer_Overread__char_alloca_loop_02_bad();
	CWE126_Buffer_Overread__char_alloca_loop_03_bad();
	CWE126_Buffer_Overread__char_alloca_loop_04_bad();
	CWE126_Buffer_Overread__char_alloca_loop_05_bad();
	CWE126_Buffer_Overread__char_alloca_loop_06_bad();
	CWE126_Buffer_Overread__char_alloca_loop_07_bad();
	CWE126_Buffer_Overread__char_alloca_loop_08_bad();
	CWE126_Buffer_Overread__char_alloca_loop_09_bad();
	CWE126_Buffer_Overread__char_alloca_loop_10_bad();
	CWE126_Buffer_Overread__char_alloca_loop_11_bad();
	CWE126_Buffer_Overread__char_alloca_loop_12_bad();
	CWE126_Buffer_Overread__char_alloca_loop_13_bad();
	CWE126_Buffer_Overread__char_alloca_loop_14_bad();
	CWE126_Buffer_Overread__char_alloca_loop_15_bad();
	CWE126_Buffer_Overread__char_alloca_loop_16_bad();
	CWE126_Buffer_Overread__char_alloca_loop_17_bad();
	CWE126_Buffer_Overread__char_alloca_loop_18_bad();
	CWE126_Buffer_Overread__char_alloca_loop_31_bad();
	CWE126_Buffer_Overread__char_alloca_loop_32_bad();
	CWE126_Buffer_Overread__char_alloca_loop_34_bad();
	CWE126_Buffer_Overread__char_alloca_loop_41_bad();
	CWE126_Buffer_Overread__char_alloca_loop_44_bad();
	CWE126_Buffer_Overread__char_alloca_loop_45_bad();
	CWE126_Buffer_Overread__char_alloca_loop_51_bad();
	CWE126_Buffer_Overread__char_alloca_loop_52_bad();
	CWE126_Buffer_Overread__char_alloca_loop_53_bad();
	CWE126_Buffer_Overread__char_alloca_loop_54_bad();
	CWE126_Buffer_Overread__char_alloca_loop_63_bad();
	CWE126_Buffer_Overread__char_alloca_loop_64_bad();
	CWE126_Buffer_Overread__char_alloca_loop_65_bad();
	CWE126_Buffer_Overread__char_alloca_loop_66_bad();
	CWE126_Buffer_Overread__char_alloca_loop_67_bad();
	CWE126_Buffer_Overread__char_alloca_loop_68_bad();

	return 0;
}
