#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__char_alloca_memcpy_01_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_02_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_03_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_04_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_05_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_06_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_07_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_08_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_09_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_10_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_11_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_12_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_13_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_14_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_15_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_16_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_17_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_18_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_31_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_32_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_34_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_41_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_44_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_45_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_51_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_52_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_53_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_54_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_63_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_64_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_65_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_66_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_67_good();
	CWE126_Buffer_Overread__char_alloca_memcpy_68_good();

	CWE126_Buffer_Overread__char_alloca_memcpy_01_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_02_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_03_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_04_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_05_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_06_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_07_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_08_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_09_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_10_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_11_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_12_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_13_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_14_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_15_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_16_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_17_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_18_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_31_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_32_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_34_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_41_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_44_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_45_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_51_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_52_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_53_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_54_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_63_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_64_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_65_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_66_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_67_bad();
	CWE126_Buffer_Overread__char_alloca_memcpy_68_bad();

	return 0;
}
