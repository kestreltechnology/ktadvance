#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__malloc_free_struct_01_good();
	CWE416_Use_After_Free__malloc_free_struct_02_good();
	CWE416_Use_After_Free__malloc_free_struct_03_good();
	CWE416_Use_After_Free__malloc_free_struct_04_good();
	CWE416_Use_After_Free__malloc_free_struct_05_good();
	CWE416_Use_After_Free__malloc_free_struct_06_good();
	CWE416_Use_After_Free__malloc_free_struct_07_good();
	CWE416_Use_After_Free__malloc_free_struct_08_good();
	CWE416_Use_After_Free__malloc_free_struct_09_good();
	CWE416_Use_After_Free__malloc_free_struct_10_good();
	CWE416_Use_After_Free__malloc_free_struct_11_good();
	CWE416_Use_After_Free__malloc_free_struct_12_good();
	CWE416_Use_After_Free__malloc_free_struct_13_good();
	CWE416_Use_After_Free__malloc_free_struct_14_good();
	CWE416_Use_After_Free__malloc_free_struct_15_good();
	CWE416_Use_After_Free__malloc_free_struct_16_good();
	CWE416_Use_After_Free__malloc_free_struct_17_good();
	CWE416_Use_After_Free__malloc_free_struct_18_good();
	CWE416_Use_After_Free__malloc_free_struct_63_good();
	CWE416_Use_After_Free__malloc_free_struct_64_good();

	CWE416_Use_After_Free__malloc_free_struct_01_bad();
	CWE416_Use_After_Free__malloc_free_struct_02_bad();
	CWE416_Use_After_Free__malloc_free_struct_03_bad();
	CWE416_Use_After_Free__malloc_free_struct_04_bad();
	CWE416_Use_After_Free__malloc_free_struct_05_bad();
	CWE416_Use_After_Free__malloc_free_struct_06_bad();
	CWE416_Use_After_Free__malloc_free_struct_07_bad();
	CWE416_Use_After_Free__malloc_free_struct_08_bad();
	CWE416_Use_After_Free__malloc_free_struct_09_bad();
	CWE416_Use_After_Free__malloc_free_struct_10_bad();
	CWE416_Use_After_Free__malloc_free_struct_11_bad();
	CWE416_Use_After_Free__malloc_free_struct_12_bad();
	CWE416_Use_After_Free__malloc_free_struct_13_bad();
	CWE416_Use_After_Free__malloc_free_struct_14_bad();
	CWE416_Use_After_Free__malloc_free_struct_15_bad();
	CWE416_Use_After_Free__malloc_free_struct_16_bad();
	CWE416_Use_After_Free__malloc_free_struct_17_bad();
	CWE416_Use_After_Free__malloc_free_struct_18_bad();
	CWE416_Use_After_Free__malloc_free_struct_63_bad();
	CWE416_Use_After_Free__malloc_free_struct_64_bad();

	return 0;
}
