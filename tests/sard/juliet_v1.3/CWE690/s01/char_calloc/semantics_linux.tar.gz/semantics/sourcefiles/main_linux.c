#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE690_NULL_Deref_From_Return__char_calloc_01_good();
	CWE690_NULL_Deref_From_Return__char_calloc_02_good();
	CWE690_NULL_Deref_From_Return__char_calloc_03_good();
	CWE690_NULL_Deref_From_Return__char_calloc_04_good();
	CWE690_NULL_Deref_From_Return__char_calloc_05_good();
	CWE690_NULL_Deref_From_Return__char_calloc_06_good();
	CWE690_NULL_Deref_From_Return__char_calloc_07_good();
	CWE690_NULL_Deref_From_Return__char_calloc_08_good();
	CWE690_NULL_Deref_From_Return__char_calloc_09_good();
	CWE690_NULL_Deref_From_Return__char_calloc_10_good();
	CWE690_NULL_Deref_From_Return__char_calloc_11_good();
	CWE690_NULL_Deref_From_Return__char_calloc_12_good();
	CWE690_NULL_Deref_From_Return__char_calloc_13_good();
	CWE690_NULL_Deref_From_Return__char_calloc_14_good();
	CWE690_NULL_Deref_From_Return__char_calloc_15_good();
	CWE690_NULL_Deref_From_Return__char_calloc_16_good();
	CWE690_NULL_Deref_From_Return__char_calloc_17_good();
	CWE690_NULL_Deref_From_Return__char_calloc_18_good();
	CWE690_NULL_Deref_From_Return__char_calloc_21_good();
	CWE690_NULL_Deref_From_Return__char_calloc_22_good();
	CWE690_NULL_Deref_From_Return__char_calloc_31_good();
	CWE690_NULL_Deref_From_Return__char_calloc_32_good();
	CWE690_NULL_Deref_From_Return__char_calloc_34_good();
	CWE690_NULL_Deref_From_Return__char_calloc_41_good();
	CWE690_NULL_Deref_From_Return__char_calloc_42_good();
	CWE690_NULL_Deref_From_Return__char_calloc_44_good();
	CWE690_NULL_Deref_From_Return__char_calloc_45_good();
	CWE690_NULL_Deref_From_Return__char_calloc_51_good();
	CWE690_NULL_Deref_From_Return__char_calloc_52_good();
	CWE690_NULL_Deref_From_Return__char_calloc_53_good();
	CWE690_NULL_Deref_From_Return__char_calloc_54_good();
	CWE690_NULL_Deref_From_Return__char_calloc_61_good();
	CWE690_NULL_Deref_From_Return__char_calloc_63_good();
	CWE690_NULL_Deref_From_Return__char_calloc_64_good();
	CWE690_NULL_Deref_From_Return__char_calloc_65_good();
	CWE690_NULL_Deref_From_Return__char_calloc_66_good();
	CWE690_NULL_Deref_From_Return__char_calloc_67_good();
	CWE690_NULL_Deref_From_Return__char_calloc_68_good();

	CWE690_NULL_Deref_From_Return__char_calloc_01_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_02_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_03_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_04_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_05_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_06_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_07_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_08_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_09_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_10_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_11_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_12_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_13_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_14_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_15_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_16_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_17_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_18_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_21_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_22_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_31_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_32_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_34_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_41_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_42_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_44_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_45_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_51_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_52_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_53_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_54_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_61_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_63_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_64_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_65_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_66_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_67_bad();
	CWE690_NULL_Deref_From_Return__char_calloc_68_bad();

	return 0;
}
