#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE758_Undefined_Behavior__char_malloc_use_01_good();
	CWE758_Undefined_Behavior__char_malloc_use_02_good();
	CWE758_Undefined_Behavior__char_malloc_use_03_good();
	CWE758_Undefined_Behavior__char_malloc_use_04_good();
	CWE758_Undefined_Behavior__char_malloc_use_05_good();
	CWE758_Undefined_Behavior__char_malloc_use_06_good();
	CWE758_Undefined_Behavior__char_malloc_use_07_good();
	CWE758_Undefined_Behavior__char_malloc_use_08_good();
	CWE758_Undefined_Behavior__char_malloc_use_09_good();
	CWE758_Undefined_Behavior__char_malloc_use_10_good();
	CWE758_Undefined_Behavior__char_malloc_use_11_good();
	CWE758_Undefined_Behavior__char_malloc_use_12_good();
	CWE758_Undefined_Behavior__char_malloc_use_13_good();
	CWE758_Undefined_Behavior__char_malloc_use_14_good();
	CWE758_Undefined_Behavior__char_malloc_use_15_good();
	CWE758_Undefined_Behavior__char_malloc_use_16_good();
	CWE758_Undefined_Behavior__char_malloc_use_17_good();
	CWE758_Undefined_Behavior__char_malloc_use_18_good();

	CWE758_Undefined_Behavior__char_malloc_use_01_bad();
	CWE758_Undefined_Behavior__char_malloc_use_02_bad();
	CWE758_Undefined_Behavior__char_malloc_use_03_bad();
	CWE758_Undefined_Behavior__char_malloc_use_04_bad();
	CWE758_Undefined_Behavior__char_malloc_use_05_bad();
	CWE758_Undefined_Behavior__char_malloc_use_06_bad();
	CWE758_Undefined_Behavior__char_malloc_use_07_bad();
	CWE758_Undefined_Behavior__char_malloc_use_08_bad();
	CWE758_Undefined_Behavior__char_malloc_use_09_bad();
	CWE758_Undefined_Behavior__char_malloc_use_10_bad();
	CWE758_Undefined_Behavior__char_malloc_use_11_bad();
	CWE758_Undefined_Behavior__char_malloc_use_12_bad();
	CWE758_Undefined_Behavior__char_malloc_use_13_bad();
	CWE758_Undefined_Behavior__char_malloc_use_14_bad();
	CWE758_Undefined_Behavior__char_malloc_use_15_bad();
	CWE758_Undefined_Behavior__char_malloc_use_16_bad();
	CWE758_Undefined_Behavior__char_malloc_use_17_bad();
	CWE758_Undefined_Behavior__char_malloc_use_18_bad();

	return 0;
}
