#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__malloc_free_char_01_good();
	CWE416_Use_After_Free__malloc_free_char_02_good();
	CWE416_Use_After_Free__malloc_free_char_03_good();
	CWE416_Use_After_Free__malloc_free_char_04_good();
	CWE416_Use_After_Free__malloc_free_char_05_good();
	CWE416_Use_After_Free__malloc_free_char_06_good();
	CWE416_Use_After_Free__malloc_free_char_07_good();
	CWE416_Use_After_Free__malloc_free_char_08_good();
	CWE416_Use_After_Free__malloc_free_char_09_good();
	CWE416_Use_After_Free__malloc_free_char_10_good();
	CWE416_Use_After_Free__malloc_free_char_11_good();
	CWE416_Use_After_Free__malloc_free_char_12_good();
	CWE416_Use_After_Free__malloc_free_char_13_good();
	CWE416_Use_After_Free__malloc_free_char_14_good();
	CWE416_Use_After_Free__malloc_free_char_15_good();
	CWE416_Use_After_Free__malloc_free_char_16_good();
	CWE416_Use_After_Free__malloc_free_char_17_good();
	CWE416_Use_After_Free__malloc_free_char_18_good();
	CWE416_Use_After_Free__malloc_free_char_63_good();
	CWE416_Use_After_Free__malloc_free_char_64_good();

	CWE416_Use_After_Free__malloc_free_char_01_bad();
	CWE416_Use_After_Free__malloc_free_char_02_bad();
	CWE416_Use_After_Free__malloc_free_char_03_bad();
	CWE416_Use_After_Free__malloc_free_char_04_bad();
	CWE416_Use_After_Free__malloc_free_char_05_bad();
	CWE416_Use_After_Free__malloc_free_char_06_bad();
	CWE416_Use_After_Free__malloc_free_char_07_bad();
	CWE416_Use_After_Free__malloc_free_char_08_bad();
	CWE416_Use_After_Free__malloc_free_char_09_bad();
	CWE416_Use_After_Free__malloc_free_char_10_bad();
	CWE416_Use_After_Free__malloc_free_char_11_bad();
	CWE416_Use_After_Free__malloc_free_char_12_bad();
	CWE416_Use_After_Free__malloc_free_char_13_bad();
	CWE416_Use_After_Free__malloc_free_char_14_bad();
	CWE416_Use_After_Free__malloc_free_char_15_bad();
	CWE416_Use_After_Free__malloc_free_char_16_bad();
	CWE416_Use_After_Free__malloc_free_char_17_bad();
	CWE416_Use_After_Free__malloc_free_char_18_bad();
	CWE416_Use_After_Free__malloc_free_char_63_bad();
	CWE416_Use_After_Free__malloc_free_char_64_bad();

	return 0;
}
