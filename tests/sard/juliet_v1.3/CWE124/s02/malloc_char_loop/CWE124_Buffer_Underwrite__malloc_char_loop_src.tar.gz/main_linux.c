#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE124_Buffer_Underwrite__malloc_char_loop_01_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_02_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_03_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_04_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_05_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_06_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_07_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_08_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_09_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_10_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_11_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_12_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_13_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_14_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_15_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_16_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_17_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_18_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_21_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_22_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_31_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_32_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_34_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_41_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_42_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_44_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_45_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_51_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_52_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_53_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_54_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_61_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_63_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_64_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_65_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_66_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_67_good();
	CWE124_Buffer_Underwrite__malloc_char_loop_68_good();

	CWE124_Buffer_Underwrite__malloc_char_loop_01_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_02_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_03_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_04_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_05_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_06_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_07_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_08_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_09_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_10_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_11_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_12_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_13_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_14_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_15_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_16_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_17_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_18_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_21_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_22_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_31_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_32_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_34_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_41_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_42_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_44_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_45_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_51_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_52_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_53_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_54_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_61_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_63_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_64_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_65_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_66_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_67_bad();
	CWE124_Buffer_Underwrite__malloc_char_loop_68_bad();

	return 0;
}
