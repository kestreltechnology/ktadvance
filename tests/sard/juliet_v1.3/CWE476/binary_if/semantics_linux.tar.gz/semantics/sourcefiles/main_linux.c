#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE476_NULL_Pointer_Dereference__binary_if_01_good();
	CWE476_NULL_Pointer_Dereference__binary_if_02_good();
	CWE476_NULL_Pointer_Dereference__binary_if_03_good();
	CWE476_NULL_Pointer_Dereference__binary_if_04_good();
	CWE476_NULL_Pointer_Dereference__binary_if_05_good();
	CWE476_NULL_Pointer_Dereference__binary_if_06_good();
	CWE476_NULL_Pointer_Dereference__binary_if_07_good();
	CWE476_NULL_Pointer_Dereference__binary_if_08_good();
	CWE476_NULL_Pointer_Dereference__binary_if_09_good();
	CWE476_NULL_Pointer_Dereference__binary_if_10_good();
	CWE476_NULL_Pointer_Dereference__binary_if_11_good();
	CWE476_NULL_Pointer_Dereference__binary_if_12_good();
	CWE476_NULL_Pointer_Dereference__binary_if_13_good();
	CWE476_NULL_Pointer_Dereference__binary_if_14_good();
	CWE476_NULL_Pointer_Dereference__binary_if_15_good();
	CWE476_NULL_Pointer_Dereference__binary_if_16_good();
	CWE476_NULL_Pointer_Dereference__binary_if_17_good();
	CWE476_NULL_Pointer_Dereference__binary_if_18_good();

	CWE476_NULL_Pointer_Dereference__binary_if_01_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_02_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_03_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_04_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_05_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_06_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_07_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_08_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_09_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_10_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_11_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_12_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_13_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_14_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_15_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_16_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_17_bad();
	CWE476_NULL_Pointer_Dereference__binary_if_18_bad();

	return 0;
}
