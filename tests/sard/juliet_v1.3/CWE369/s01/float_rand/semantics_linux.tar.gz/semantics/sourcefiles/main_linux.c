#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE369_Divide_by_Zero__float_rand_01_good();
	CWE369_Divide_by_Zero__float_rand_02_good();
	CWE369_Divide_by_Zero__float_rand_03_good();
	CWE369_Divide_by_Zero__float_rand_04_good();
	CWE369_Divide_by_Zero__float_rand_05_good();
	CWE369_Divide_by_Zero__float_rand_06_good();
	CWE369_Divide_by_Zero__float_rand_07_good();
	CWE369_Divide_by_Zero__float_rand_08_good();
	CWE369_Divide_by_Zero__float_rand_09_good();
	CWE369_Divide_by_Zero__float_rand_10_good();
	CWE369_Divide_by_Zero__float_rand_11_good();
	CWE369_Divide_by_Zero__float_rand_12_good();
	CWE369_Divide_by_Zero__float_rand_13_good();
	CWE369_Divide_by_Zero__float_rand_14_good();
	CWE369_Divide_by_Zero__float_rand_15_good();
	CWE369_Divide_by_Zero__float_rand_16_good();
	CWE369_Divide_by_Zero__float_rand_17_good();
	CWE369_Divide_by_Zero__float_rand_18_good();
	CWE369_Divide_by_Zero__float_rand_21_good();
	CWE369_Divide_by_Zero__float_rand_22_good();
	CWE369_Divide_by_Zero__float_rand_31_good();
	CWE369_Divide_by_Zero__float_rand_32_good();
	CWE369_Divide_by_Zero__float_rand_34_good();
	CWE369_Divide_by_Zero__float_rand_41_good();
	CWE369_Divide_by_Zero__float_rand_42_good();
	CWE369_Divide_by_Zero__float_rand_44_good();
	CWE369_Divide_by_Zero__float_rand_45_good();
	CWE369_Divide_by_Zero__float_rand_51_good();
	CWE369_Divide_by_Zero__float_rand_52_good();
	CWE369_Divide_by_Zero__float_rand_53_good();
	CWE369_Divide_by_Zero__float_rand_54_good();
	CWE369_Divide_by_Zero__float_rand_61_good();
	CWE369_Divide_by_Zero__float_rand_63_good();
	CWE369_Divide_by_Zero__float_rand_64_good();
	CWE369_Divide_by_Zero__float_rand_65_good();
	CWE369_Divide_by_Zero__float_rand_66_good();
	CWE369_Divide_by_Zero__float_rand_67_good();
	CWE369_Divide_by_Zero__float_rand_68_good();

	CWE369_Divide_by_Zero__float_rand_01_bad();
	CWE369_Divide_by_Zero__float_rand_02_bad();
	CWE369_Divide_by_Zero__float_rand_03_bad();
	CWE369_Divide_by_Zero__float_rand_04_bad();
	CWE369_Divide_by_Zero__float_rand_05_bad();
	CWE369_Divide_by_Zero__float_rand_06_bad();
	CWE369_Divide_by_Zero__float_rand_07_bad();
	CWE369_Divide_by_Zero__float_rand_08_bad();
	CWE369_Divide_by_Zero__float_rand_09_bad();
	CWE369_Divide_by_Zero__float_rand_10_bad();
	CWE369_Divide_by_Zero__float_rand_11_bad();
	CWE369_Divide_by_Zero__float_rand_12_bad();
	CWE369_Divide_by_Zero__float_rand_13_bad();
	CWE369_Divide_by_Zero__float_rand_14_bad();
	CWE369_Divide_by_Zero__float_rand_15_bad();
	CWE369_Divide_by_Zero__float_rand_16_bad();
	CWE369_Divide_by_Zero__float_rand_17_bad();
	CWE369_Divide_by_Zero__float_rand_18_bad();
	CWE369_Divide_by_Zero__float_rand_21_bad();
	CWE369_Divide_by_Zero__float_rand_22_bad();
	CWE369_Divide_by_Zero__float_rand_31_bad();
	CWE369_Divide_by_Zero__float_rand_32_bad();
	CWE369_Divide_by_Zero__float_rand_34_bad();
	CWE369_Divide_by_Zero__float_rand_41_bad();
	CWE369_Divide_by_Zero__float_rand_42_bad();
	CWE369_Divide_by_Zero__float_rand_44_bad();
	CWE369_Divide_by_Zero__float_rand_45_bad();
	CWE369_Divide_by_Zero__float_rand_51_bad();
	CWE369_Divide_by_Zero__float_rand_52_bad();
	CWE369_Divide_by_Zero__float_rand_53_bad();
	CWE369_Divide_by_Zero__float_rand_54_bad();
	CWE369_Divide_by_Zero__float_rand_61_bad();
	CWE369_Divide_by_Zero__float_rand_63_bad();
	CWE369_Divide_by_Zero__float_rand_64_bad();
	CWE369_Divide_by_Zero__float_rand_65_bad();
	CWE369_Divide_by_Zero__float_rand_66_bad();
	CWE369_Divide_by_Zero__float_rand_67_bad();
	CWE369_Divide_by_Zero__float_rand_68_bad();

	return 0;
}
