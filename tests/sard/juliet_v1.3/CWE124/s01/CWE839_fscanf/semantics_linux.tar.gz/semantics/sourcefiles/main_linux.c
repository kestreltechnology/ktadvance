#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE124_Buffer_Underwrite__CWE839_fscanf_01_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_02_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_03_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_04_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_05_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_06_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_07_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_08_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_09_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_10_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_11_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_12_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_13_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_14_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_15_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_16_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_17_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_18_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_21_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_22_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_31_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_32_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_34_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_41_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_42_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_44_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_45_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_51_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_52_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_53_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_54_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_61_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_63_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_64_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_65_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_66_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_67_good();
	CWE124_Buffer_Underwrite__CWE839_fscanf_68_good();

	CWE124_Buffer_Underwrite__CWE839_fscanf_01_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_02_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_03_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_04_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_05_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_06_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_07_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_08_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_09_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_10_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_11_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_12_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_13_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_14_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_15_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_16_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_17_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_18_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_21_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_22_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_31_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_32_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_34_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_41_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_42_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_44_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_45_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_51_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_52_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_53_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_54_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_61_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_63_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_64_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_65_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_66_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_67_bad();
	CWE124_Buffer_Underwrite__CWE839_fscanf_68_bad();

	return 0;
}
