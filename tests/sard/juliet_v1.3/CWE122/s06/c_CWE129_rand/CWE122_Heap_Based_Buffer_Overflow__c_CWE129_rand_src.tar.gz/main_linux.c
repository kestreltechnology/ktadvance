#include <time.h>   /* for time() */
#include <stdlib.h> /* for srand() */

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {

        /* seed randomness */

        srand( (unsigned)time(NULL) );

        globalArgc = argc;
        globalArgv = argv;

	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_01_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_02_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_03_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_04_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_05_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_06_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_07_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_08_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_09_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_10_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_11_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_12_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_13_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_14_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_15_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_16_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_17_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_18_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_21_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_22_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_31_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_32_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_34_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_41_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_42_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_44_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_45_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_51_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_52_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_53_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_54_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_61_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_63_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_64_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_65_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_66_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_67_good();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68_good();

	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_01_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_02_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_03_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_04_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_05_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_06_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_07_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_08_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_09_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_10_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_11_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_12_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_13_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_14_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_15_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_16_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_17_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_18_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_21_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_22_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_31_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_32_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_34_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_41_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_42_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_44_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_45_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_51_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_52_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_53_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_54_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_61_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_63_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_64_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_65_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_66_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_67_bad();
	CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68_bad();

	return 0;
}
