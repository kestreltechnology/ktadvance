#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE562_Return_of_Stack_Variable_Address__return_buf_01_good();

	CWE562_Return_of_Stack_Variable_Address__return_buf_01_bad();

	return 0;
}
