#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE690_NULL_Deref_From_Return__fopen_01_good();
	CWE690_NULL_Deref_From_Return__fopen_02_good();
	CWE690_NULL_Deref_From_Return__fopen_03_good();
	CWE690_NULL_Deref_From_Return__fopen_04_good();
	CWE690_NULL_Deref_From_Return__fopen_05_good();
	CWE690_NULL_Deref_From_Return__fopen_06_good();
	CWE690_NULL_Deref_From_Return__fopen_07_good();
	CWE690_NULL_Deref_From_Return__fopen_08_good();
	CWE690_NULL_Deref_From_Return__fopen_09_good();
	CWE690_NULL_Deref_From_Return__fopen_10_good();
	CWE690_NULL_Deref_From_Return__fopen_11_good();
	CWE690_NULL_Deref_From_Return__fopen_12_good();
	CWE690_NULL_Deref_From_Return__fopen_13_good();
	CWE690_NULL_Deref_From_Return__fopen_14_good();
	CWE690_NULL_Deref_From_Return__fopen_15_good();
	CWE690_NULL_Deref_From_Return__fopen_16_good();
	CWE690_NULL_Deref_From_Return__fopen_17_good();
	CWE690_NULL_Deref_From_Return__fopen_18_good();
	CWE690_NULL_Deref_From_Return__fopen_21_good();
	CWE690_NULL_Deref_From_Return__fopen_22_good();
	CWE690_NULL_Deref_From_Return__fopen_31_good();
	CWE690_NULL_Deref_From_Return__fopen_32_good();
	CWE690_NULL_Deref_From_Return__fopen_34_good();
	CWE690_NULL_Deref_From_Return__fopen_41_good();
	CWE690_NULL_Deref_From_Return__fopen_42_good();
	CWE690_NULL_Deref_From_Return__fopen_44_good();
	CWE690_NULL_Deref_From_Return__fopen_45_good();
	CWE690_NULL_Deref_From_Return__fopen_51_good();
	CWE690_NULL_Deref_From_Return__fopen_52_good();
	CWE690_NULL_Deref_From_Return__fopen_53_good();
	CWE690_NULL_Deref_From_Return__fopen_54_good();
	CWE690_NULL_Deref_From_Return__fopen_61_good();
	CWE690_NULL_Deref_From_Return__fopen_63_good();
	CWE690_NULL_Deref_From_Return__fopen_64_good();
	CWE690_NULL_Deref_From_Return__fopen_65_good();
	CWE690_NULL_Deref_From_Return__fopen_66_good();
	CWE690_NULL_Deref_From_Return__fopen_67_good();
	CWE690_NULL_Deref_From_Return__fopen_68_good();

	CWE690_NULL_Deref_From_Return__fopen_01_bad();
	CWE690_NULL_Deref_From_Return__fopen_02_bad();
	CWE690_NULL_Deref_From_Return__fopen_03_bad();
	CWE690_NULL_Deref_From_Return__fopen_04_bad();
	CWE690_NULL_Deref_From_Return__fopen_05_bad();
	CWE690_NULL_Deref_From_Return__fopen_06_bad();
	CWE690_NULL_Deref_From_Return__fopen_07_bad();
	CWE690_NULL_Deref_From_Return__fopen_08_bad();
	CWE690_NULL_Deref_From_Return__fopen_09_bad();
	CWE690_NULL_Deref_From_Return__fopen_10_bad();
	CWE690_NULL_Deref_From_Return__fopen_11_bad();
	CWE690_NULL_Deref_From_Return__fopen_12_bad();
	CWE690_NULL_Deref_From_Return__fopen_13_bad();
	CWE690_NULL_Deref_From_Return__fopen_14_bad();
	CWE690_NULL_Deref_From_Return__fopen_15_bad();
	CWE690_NULL_Deref_From_Return__fopen_16_bad();
	CWE690_NULL_Deref_From_Return__fopen_17_bad();
	CWE690_NULL_Deref_From_Return__fopen_18_bad();
	CWE690_NULL_Deref_From_Return__fopen_21_bad();
	CWE690_NULL_Deref_From_Return__fopen_22_bad();
	CWE690_NULL_Deref_From_Return__fopen_31_bad();
	CWE690_NULL_Deref_From_Return__fopen_32_bad();
	CWE690_NULL_Deref_From_Return__fopen_34_bad();
	CWE690_NULL_Deref_From_Return__fopen_41_bad();
	CWE690_NULL_Deref_From_Return__fopen_42_bad();
	CWE690_NULL_Deref_From_Return__fopen_44_bad();
	CWE690_NULL_Deref_From_Return__fopen_45_bad();
	CWE690_NULL_Deref_From_Return__fopen_51_bad();
	CWE690_NULL_Deref_From_Return__fopen_52_bad();
	CWE690_NULL_Deref_From_Return__fopen_53_bad();
	CWE690_NULL_Deref_From_Return__fopen_54_bad();
	CWE690_NULL_Deref_From_Return__fopen_61_bad();
	CWE690_NULL_Deref_From_Return__fopen_63_bad();
	CWE690_NULL_Deref_From_Return__fopen_64_bad();
	CWE690_NULL_Deref_From_Return__fopen_65_bad();
	CWE690_NULL_Deref_From_Return__fopen_66_bad();
	CWE690_NULL_Deref_From_Return__fopen_67_bad();
	CWE690_NULL_Deref_From_Return__fopen_68_bad();

	return 0;
}
