#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE690_NULL_Deref_From_Return__struct_malloc_01_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_02_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_03_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_04_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_05_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_06_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_07_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_08_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_09_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_10_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_11_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_12_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_13_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_14_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_15_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_16_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_17_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_18_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_21_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_22_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_31_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_32_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_34_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_41_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_42_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_44_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_45_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_51_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_52_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_53_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_54_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_61_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_63_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_64_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_65_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_66_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_67_good();
	CWE690_NULL_Deref_From_Return__struct_malloc_68_good();

	CWE690_NULL_Deref_From_Return__struct_malloc_01_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_02_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_03_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_04_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_05_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_06_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_07_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_08_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_09_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_10_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_11_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_12_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_13_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_14_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_15_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_16_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_17_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_18_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_21_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_22_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_31_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_32_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_34_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_41_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_42_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_44_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_45_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_51_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_52_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_53_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_54_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_61_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_63_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_64_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_65_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_66_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_67_bad();
	CWE690_NULL_Deref_From_Return__struct_malloc_68_bad();

	return 0;
}
