#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__malloc_free_long_01_good();
	CWE416_Use_After_Free__malloc_free_long_02_good();
	CWE416_Use_After_Free__malloc_free_long_03_good();
	CWE416_Use_After_Free__malloc_free_long_04_good();
	CWE416_Use_After_Free__malloc_free_long_05_good();
	CWE416_Use_After_Free__malloc_free_long_06_good();
	CWE416_Use_After_Free__malloc_free_long_07_good();
	CWE416_Use_After_Free__malloc_free_long_08_good();
	CWE416_Use_After_Free__malloc_free_long_09_good();
	CWE416_Use_After_Free__malloc_free_long_10_good();
	CWE416_Use_After_Free__malloc_free_long_11_good();
	CWE416_Use_After_Free__malloc_free_long_12_good();
	CWE416_Use_After_Free__malloc_free_long_13_good();
	CWE416_Use_After_Free__malloc_free_long_14_good();
	CWE416_Use_After_Free__malloc_free_long_15_good();
	CWE416_Use_After_Free__malloc_free_long_16_good();
	CWE416_Use_After_Free__malloc_free_long_17_good();
	CWE416_Use_After_Free__malloc_free_long_18_good();
	CWE416_Use_After_Free__malloc_free_long_63_good();
	CWE416_Use_After_Free__malloc_free_long_64_good();

	CWE416_Use_After_Free__malloc_free_long_01_bad();
	CWE416_Use_After_Free__malloc_free_long_02_bad();
	CWE416_Use_After_Free__malloc_free_long_03_bad();
	CWE416_Use_After_Free__malloc_free_long_04_bad();
	CWE416_Use_After_Free__malloc_free_long_05_bad();
	CWE416_Use_After_Free__malloc_free_long_06_bad();
	CWE416_Use_After_Free__malloc_free_long_07_bad();
	CWE416_Use_After_Free__malloc_free_long_08_bad();
	CWE416_Use_After_Free__malloc_free_long_09_bad();
	CWE416_Use_After_Free__malloc_free_long_10_bad();
	CWE416_Use_After_Free__malloc_free_long_11_bad();
	CWE416_Use_After_Free__malloc_free_long_12_bad();
	CWE416_Use_After_Free__malloc_free_long_13_bad();
	CWE416_Use_After_Free__malloc_free_long_14_bad();
	CWE416_Use_After_Free__malloc_free_long_15_bad();
	CWE416_Use_After_Free__malloc_free_long_16_bad();
	CWE416_Use_After_Free__malloc_free_long_17_bad();
	CWE416_Use_After_Free__malloc_free_long_18_bad();
	CWE416_Use_After_Free__malloc_free_long_63_bad();
	CWE416_Use_After_Free__malloc_free_long_64_bad();

	return 0;
}
