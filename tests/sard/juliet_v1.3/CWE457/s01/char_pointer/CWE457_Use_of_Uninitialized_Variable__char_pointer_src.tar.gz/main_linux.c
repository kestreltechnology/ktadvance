#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE457_Use_of_Uninitialized_Variable__char_pointer_01_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_02_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_03_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_04_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_05_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_06_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_07_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_08_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_09_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_10_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_11_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_12_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_13_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_14_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_15_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_16_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_17_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_18_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_63_good();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_64_good();

	CWE457_Use_of_Uninitialized_Variable__char_pointer_01_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_02_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_03_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_04_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_05_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_06_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_07_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_08_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_09_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_10_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_11_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_12_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_13_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_14_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_15_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_16_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_17_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_18_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_63_bad();
	CWE457_Use_of_Uninitialized_Variable__char_pointer_64_bad();

	return 0;
}
