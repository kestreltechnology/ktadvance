#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE369_Divide_by_Zero__float_zero_01_good();
	CWE369_Divide_by_Zero__float_zero_02_good();
	CWE369_Divide_by_Zero__float_zero_03_good();
	CWE369_Divide_by_Zero__float_zero_04_good();
	CWE369_Divide_by_Zero__float_zero_05_good();
	CWE369_Divide_by_Zero__float_zero_06_good();
	CWE369_Divide_by_Zero__float_zero_07_good();
	CWE369_Divide_by_Zero__float_zero_08_good();
	CWE369_Divide_by_Zero__float_zero_09_good();
	CWE369_Divide_by_Zero__float_zero_10_good();
	CWE369_Divide_by_Zero__float_zero_11_good();
	CWE369_Divide_by_Zero__float_zero_12_good();
	CWE369_Divide_by_Zero__float_zero_13_good();
	CWE369_Divide_by_Zero__float_zero_14_good();
	CWE369_Divide_by_Zero__float_zero_15_good();
	CWE369_Divide_by_Zero__float_zero_16_good();
	CWE369_Divide_by_Zero__float_zero_17_good();
	CWE369_Divide_by_Zero__float_zero_18_good();
	CWE369_Divide_by_Zero__float_zero_21_good();
	CWE369_Divide_by_Zero__float_zero_22_good();
	CWE369_Divide_by_Zero__float_zero_31_good();
	CWE369_Divide_by_Zero__float_zero_32_good();
	CWE369_Divide_by_Zero__float_zero_34_good();
	CWE369_Divide_by_Zero__float_zero_41_good();
	CWE369_Divide_by_Zero__float_zero_42_good();
	CWE369_Divide_by_Zero__float_zero_44_good();
	CWE369_Divide_by_Zero__float_zero_45_good();
	CWE369_Divide_by_Zero__float_zero_51_good();
	CWE369_Divide_by_Zero__float_zero_52_good();
	CWE369_Divide_by_Zero__float_zero_53_good();
	CWE369_Divide_by_Zero__float_zero_54_good();
	CWE369_Divide_by_Zero__float_zero_61_good();
	CWE369_Divide_by_Zero__float_zero_63_good();
	CWE369_Divide_by_Zero__float_zero_64_good();
	CWE369_Divide_by_Zero__float_zero_65_good();
	CWE369_Divide_by_Zero__float_zero_66_good();
	CWE369_Divide_by_Zero__float_zero_67_good();
	CWE369_Divide_by_Zero__float_zero_68_good();

	CWE369_Divide_by_Zero__float_zero_01_bad();
	CWE369_Divide_by_Zero__float_zero_02_bad();
	CWE369_Divide_by_Zero__float_zero_03_bad();
	CWE369_Divide_by_Zero__float_zero_04_bad();
	CWE369_Divide_by_Zero__float_zero_05_bad();
	CWE369_Divide_by_Zero__float_zero_06_bad();
	CWE369_Divide_by_Zero__float_zero_07_bad();
	CWE369_Divide_by_Zero__float_zero_08_bad();
	CWE369_Divide_by_Zero__float_zero_09_bad();
	CWE369_Divide_by_Zero__float_zero_10_bad();
	CWE369_Divide_by_Zero__float_zero_11_bad();
	CWE369_Divide_by_Zero__float_zero_12_bad();
	CWE369_Divide_by_Zero__float_zero_13_bad();
	CWE369_Divide_by_Zero__float_zero_14_bad();
	CWE369_Divide_by_Zero__float_zero_15_bad();
	CWE369_Divide_by_Zero__float_zero_16_bad();
	CWE369_Divide_by_Zero__float_zero_17_bad();
	CWE369_Divide_by_Zero__float_zero_18_bad();
	CWE369_Divide_by_Zero__float_zero_21_bad();
	CWE369_Divide_by_Zero__float_zero_22_bad();
	CWE369_Divide_by_Zero__float_zero_31_bad();
	CWE369_Divide_by_Zero__float_zero_32_bad();
	CWE369_Divide_by_Zero__float_zero_34_bad();
	CWE369_Divide_by_Zero__float_zero_41_bad();
	CWE369_Divide_by_Zero__float_zero_42_bad();
	CWE369_Divide_by_Zero__float_zero_44_bad();
	CWE369_Divide_by_Zero__float_zero_45_bad();
	CWE369_Divide_by_Zero__float_zero_51_bad();
	CWE369_Divide_by_Zero__float_zero_52_bad();
	CWE369_Divide_by_Zero__float_zero_53_bad();
	CWE369_Divide_by_Zero__float_zero_54_bad();
	CWE369_Divide_by_Zero__float_zero_61_bad();
	CWE369_Divide_by_Zero__float_zero_63_bad();
	CWE369_Divide_by_Zero__float_zero_64_bad();
	CWE369_Divide_by_Zero__float_zero_65_bad();
	CWE369_Divide_by_Zero__float_zero_66_bad();
	CWE369_Divide_by_Zero__float_zero_67_bad();
	CWE369_Divide_by_Zero__float_zero_68_bad();

	return 0;
}
