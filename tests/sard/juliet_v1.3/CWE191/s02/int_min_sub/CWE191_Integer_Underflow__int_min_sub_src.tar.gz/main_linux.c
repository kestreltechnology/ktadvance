#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE191_Integer_Underflow__int_min_sub_01_good();
	CWE191_Integer_Underflow__int_min_sub_02_good();
	CWE191_Integer_Underflow__int_min_sub_03_good();
	CWE191_Integer_Underflow__int_min_sub_04_good();
	CWE191_Integer_Underflow__int_min_sub_05_good();
	CWE191_Integer_Underflow__int_min_sub_06_good();
	CWE191_Integer_Underflow__int_min_sub_07_good();
	CWE191_Integer_Underflow__int_min_sub_08_good();
	CWE191_Integer_Underflow__int_min_sub_09_good();
	CWE191_Integer_Underflow__int_min_sub_10_good();
	CWE191_Integer_Underflow__int_min_sub_11_good();
	CWE191_Integer_Underflow__int_min_sub_12_good();
	CWE191_Integer_Underflow__int_min_sub_13_good();
	CWE191_Integer_Underflow__int_min_sub_14_good();
	CWE191_Integer_Underflow__int_min_sub_15_good();
	CWE191_Integer_Underflow__int_min_sub_16_good();
	CWE191_Integer_Underflow__int_min_sub_17_good();
	CWE191_Integer_Underflow__int_min_sub_18_good();
	CWE191_Integer_Underflow__int_min_sub_21_good();
	CWE191_Integer_Underflow__int_min_sub_22_good();
	CWE191_Integer_Underflow__int_min_sub_31_good();
	CWE191_Integer_Underflow__int_min_sub_32_good();
	CWE191_Integer_Underflow__int_min_sub_34_good();
	CWE191_Integer_Underflow__int_min_sub_41_good();
	CWE191_Integer_Underflow__int_min_sub_42_good();
	CWE191_Integer_Underflow__int_min_sub_44_good();
	CWE191_Integer_Underflow__int_min_sub_45_good();
	CWE191_Integer_Underflow__int_min_sub_51_good();
	CWE191_Integer_Underflow__int_min_sub_52_good();
	CWE191_Integer_Underflow__int_min_sub_53_good();
	CWE191_Integer_Underflow__int_min_sub_54_good();
	CWE191_Integer_Underflow__int_min_sub_61_good();
	CWE191_Integer_Underflow__int_min_sub_63_good();
	CWE191_Integer_Underflow__int_min_sub_64_good();
	CWE191_Integer_Underflow__int_min_sub_65_good();
	CWE191_Integer_Underflow__int_min_sub_66_good();
	CWE191_Integer_Underflow__int_min_sub_67_good();
	CWE191_Integer_Underflow__int_min_sub_68_good();

	CWE191_Integer_Underflow__int_min_sub_01_bad();
	CWE191_Integer_Underflow__int_min_sub_02_bad();
	CWE191_Integer_Underflow__int_min_sub_03_bad();
	CWE191_Integer_Underflow__int_min_sub_04_bad();
	CWE191_Integer_Underflow__int_min_sub_05_bad();
	CWE191_Integer_Underflow__int_min_sub_06_bad();
	CWE191_Integer_Underflow__int_min_sub_07_bad();
	CWE191_Integer_Underflow__int_min_sub_08_bad();
	CWE191_Integer_Underflow__int_min_sub_09_bad();
	CWE191_Integer_Underflow__int_min_sub_10_bad();
	CWE191_Integer_Underflow__int_min_sub_11_bad();
	CWE191_Integer_Underflow__int_min_sub_12_bad();
	CWE191_Integer_Underflow__int_min_sub_13_bad();
	CWE191_Integer_Underflow__int_min_sub_14_bad();
	CWE191_Integer_Underflow__int_min_sub_15_bad();
	CWE191_Integer_Underflow__int_min_sub_16_bad();
	CWE191_Integer_Underflow__int_min_sub_17_bad();
	CWE191_Integer_Underflow__int_min_sub_18_bad();
	CWE191_Integer_Underflow__int_min_sub_21_bad();
	CWE191_Integer_Underflow__int_min_sub_22_bad();
	CWE191_Integer_Underflow__int_min_sub_31_bad();
	CWE191_Integer_Underflow__int_min_sub_32_bad();
	CWE191_Integer_Underflow__int_min_sub_34_bad();
	CWE191_Integer_Underflow__int_min_sub_41_bad();
	CWE191_Integer_Underflow__int_min_sub_42_bad();
	CWE191_Integer_Underflow__int_min_sub_44_bad();
	CWE191_Integer_Underflow__int_min_sub_45_bad();
	CWE191_Integer_Underflow__int_min_sub_51_bad();
	CWE191_Integer_Underflow__int_min_sub_52_bad();
	CWE191_Integer_Underflow__int_min_sub_53_bad();
	CWE191_Integer_Underflow__int_min_sub_54_bad();
	CWE191_Integer_Underflow__int_min_sub_61_bad();
	CWE191_Integer_Underflow__int_min_sub_63_bad();
	CWE191_Integer_Underflow__int_min_sub_64_bad();
	CWE191_Integer_Underflow__int_min_sub_65_bad();
	CWE191_Integer_Underflow__int_min_sub_66_bad();
	CWE191_Integer_Underflow__int_min_sub_67_bad();
	CWE191_Integer_Underflow__int_min_sub_68_bad();

	return 0;
}
