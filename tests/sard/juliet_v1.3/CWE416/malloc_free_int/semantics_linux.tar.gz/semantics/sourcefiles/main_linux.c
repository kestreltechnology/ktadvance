#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__malloc_free_int_01_good();
	CWE416_Use_After_Free__malloc_free_int_02_good();
	CWE416_Use_After_Free__malloc_free_int_03_good();
	CWE416_Use_After_Free__malloc_free_int_04_good();
	CWE416_Use_After_Free__malloc_free_int_05_good();
	CWE416_Use_After_Free__malloc_free_int_06_good();
	CWE416_Use_After_Free__malloc_free_int_07_good();
	CWE416_Use_After_Free__malloc_free_int_08_good();
	CWE416_Use_After_Free__malloc_free_int_09_good();
	CWE416_Use_After_Free__malloc_free_int_10_good();
	CWE416_Use_After_Free__malloc_free_int_11_good();
	CWE416_Use_After_Free__malloc_free_int_12_good();
	CWE416_Use_After_Free__malloc_free_int_13_good();
	CWE416_Use_After_Free__malloc_free_int_14_good();
	CWE416_Use_After_Free__malloc_free_int_15_good();
	CWE416_Use_After_Free__malloc_free_int_16_good();
	CWE416_Use_After_Free__malloc_free_int_17_good();
	CWE416_Use_After_Free__malloc_free_int_18_good();
	CWE416_Use_After_Free__malloc_free_int_63_good();
	CWE416_Use_After_Free__malloc_free_int_64_good();

	CWE416_Use_After_Free__malloc_free_int_01_bad();
	CWE416_Use_After_Free__malloc_free_int_02_bad();
	CWE416_Use_After_Free__malloc_free_int_03_bad();
	CWE416_Use_After_Free__malloc_free_int_04_bad();
	CWE416_Use_After_Free__malloc_free_int_05_bad();
	CWE416_Use_After_Free__malloc_free_int_06_bad();
	CWE416_Use_After_Free__malloc_free_int_07_bad();
	CWE416_Use_After_Free__malloc_free_int_08_bad();
	CWE416_Use_After_Free__malloc_free_int_09_bad();
	CWE416_Use_After_Free__malloc_free_int_10_bad();
	CWE416_Use_After_Free__malloc_free_int_11_bad();
	CWE416_Use_After_Free__malloc_free_int_12_bad();
	CWE416_Use_After_Free__malloc_free_int_13_bad();
	CWE416_Use_After_Free__malloc_free_int_14_bad();
	CWE416_Use_After_Free__malloc_free_int_15_bad();
	CWE416_Use_After_Free__malloc_free_int_16_bad();
	CWE416_Use_After_Free__malloc_free_int_17_bad();
	CWE416_Use_After_Free__malloc_free_int_18_bad();
	CWE416_Use_After_Free__malloc_free_int_63_bad();
	CWE416_Use_After_Free__malloc_free_int_64_bad();

	return 0;
}
