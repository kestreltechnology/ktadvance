#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE369_Divide_by_Zero__float_fscanf_01_good();
	CWE369_Divide_by_Zero__float_fscanf_02_good();
	CWE369_Divide_by_Zero__float_fscanf_03_good();
	CWE369_Divide_by_Zero__float_fscanf_04_good();
	CWE369_Divide_by_Zero__float_fscanf_05_good();
	CWE369_Divide_by_Zero__float_fscanf_06_good();
	CWE369_Divide_by_Zero__float_fscanf_07_good();
	CWE369_Divide_by_Zero__float_fscanf_08_good();
	CWE369_Divide_by_Zero__float_fscanf_09_good();
	CWE369_Divide_by_Zero__float_fscanf_10_good();
	CWE369_Divide_by_Zero__float_fscanf_11_good();
	CWE369_Divide_by_Zero__float_fscanf_12_good();
	CWE369_Divide_by_Zero__float_fscanf_13_good();
	CWE369_Divide_by_Zero__float_fscanf_14_good();
	CWE369_Divide_by_Zero__float_fscanf_15_good();
	CWE369_Divide_by_Zero__float_fscanf_16_good();
	CWE369_Divide_by_Zero__float_fscanf_17_good();
	CWE369_Divide_by_Zero__float_fscanf_18_good();
	CWE369_Divide_by_Zero__float_fscanf_21_good();
	CWE369_Divide_by_Zero__float_fscanf_22_good();
	CWE369_Divide_by_Zero__float_fscanf_31_good();
	CWE369_Divide_by_Zero__float_fscanf_32_good();
	CWE369_Divide_by_Zero__float_fscanf_34_good();
	CWE369_Divide_by_Zero__float_fscanf_41_good();
	CWE369_Divide_by_Zero__float_fscanf_42_good();
	CWE369_Divide_by_Zero__float_fscanf_44_good();
	CWE369_Divide_by_Zero__float_fscanf_45_good();
	CWE369_Divide_by_Zero__float_fscanf_51_good();
	CWE369_Divide_by_Zero__float_fscanf_52_good();
	CWE369_Divide_by_Zero__float_fscanf_53_good();
	CWE369_Divide_by_Zero__float_fscanf_54_good();
	CWE369_Divide_by_Zero__float_fscanf_61_good();
	CWE369_Divide_by_Zero__float_fscanf_63_good();
	CWE369_Divide_by_Zero__float_fscanf_64_good();
	CWE369_Divide_by_Zero__float_fscanf_65_good();
	CWE369_Divide_by_Zero__float_fscanf_66_good();
	CWE369_Divide_by_Zero__float_fscanf_67_good();
	CWE369_Divide_by_Zero__float_fscanf_68_good();

	CWE369_Divide_by_Zero__float_fscanf_01_bad();
	CWE369_Divide_by_Zero__float_fscanf_02_bad();
	CWE369_Divide_by_Zero__float_fscanf_03_bad();
	CWE369_Divide_by_Zero__float_fscanf_04_bad();
	CWE369_Divide_by_Zero__float_fscanf_05_bad();
	CWE369_Divide_by_Zero__float_fscanf_06_bad();
	CWE369_Divide_by_Zero__float_fscanf_07_bad();
	CWE369_Divide_by_Zero__float_fscanf_08_bad();
	CWE369_Divide_by_Zero__float_fscanf_09_bad();
	CWE369_Divide_by_Zero__float_fscanf_10_bad();
	CWE369_Divide_by_Zero__float_fscanf_11_bad();
	CWE369_Divide_by_Zero__float_fscanf_12_bad();
	CWE369_Divide_by_Zero__float_fscanf_13_bad();
	CWE369_Divide_by_Zero__float_fscanf_14_bad();
	CWE369_Divide_by_Zero__float_fscanf_15_bad();
	CWE369_Divide_by_Zero__float_fscanf_16_bad();
	CWE369_Divide_by_Zero__float_fscanf_17_bad();
	CWE369_Divide_by_Zero__float_fscanf_18_bad();
	CWE369_Divide_by_Zero__float_fscanf_21_bad();
	CWE369_Divide_by_Zero__float_fscanf_22_bad();
	CWE369_Divide_by_Zero__float_fscanf_31_bad();
	CWE369_Divide_by_Zero__float_fscanf_32_bad();
	CWE369_Divide_by_Zero__float_fscanf_34_bad();
	CWE369_Divide_by_Zero__float_fscanf_41_bad();
	CWE369_Divide_by_Zero__float_fscanf_42_bad();
	CWE369_Divide_by_Zero__float_fscanf_44_bad();
	CWE369_Divide_by_Zero__float_fscanf_45_bad();
	CWE369_Divide_by_Zero__float_fscanf_51_bad();
	CWE369_Divide_by_Zero__float_fscanf_52_bad();
	CWE369_Divide_by_Zero__float_fscanf_53_bad();
	CWE369_Divide_by_Zero__float_fscanf_54_bad();
	CWE369_Divide_by_Zero__float_fscanf_61_bad();
	CWE369_Divide_by_Zero__float_fscanf_63_bad();
	CWE369_Divide_by_Zero__float_fscanf_64_bad();
	CWE369_Divide_by_Zero__float_fscanf_65_bad();
	CWE369_Divide_by_Zero__float_fscanf_66_bad();
	CWE369_Divide_by_Zero__float_fscanf_67_bad();
	CWE369_Divide_by_Zero__float_fscanf_68_bad();

	return 0;
}
