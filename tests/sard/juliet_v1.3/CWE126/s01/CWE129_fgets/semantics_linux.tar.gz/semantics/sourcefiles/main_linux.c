#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE129_fgets_01_good();
	CWE126_Buffer_Overread__CWE129_fgets_02_good();
	CWE126_Buffer_Overread__CWE129_fgets_03_good();
	CWE126_Buffer_Overread__CWE129_fgets_04_good();
	CWE126_Buffer_Overread__CWE129_fgets_05_good();
	CWE126_Buffer_Overread__CWE129_fgets_06_good();
	CWE126_Buffer_Overread__CWE129_fgets_07_good();
	CWE126_Buffer_Overread__CWE129_fgets_08_good();
	CWE126_Buffer_Overread__CWE129_fgets_09_good();
	CWE126_Buffer_Overread__CWE129_fgets_10_good();
	CWE126_Buffer_Overread__CWE129_fgets_11_good();
	CWE126_Buffer_Overread__CWE129_fgets_12_good();
	CWE126_Buffer_Overread__CWE129_fgets_13_good();
	CWE126_Buffer_Overread__CWE129_fgets_14_good();
	CWE126_Buffer_Overread__CWE129_fgets_15_good();
	CWE126_Buffer_Overread__CWE129_fgets_16_good();
	CWE126_Buffer_Overread__CWE129_fgets_17_good();
	CWE126_Buffer_Overread__CWE129_fgets_18_good();
	CWE126_Buffer_Overread__CWE129_fgets_21_good();
	CWE126_Buffer_Overread__CWE129_fgets_22_good();
	CWE126_Buffer_Overread__CWE129_fgets_31_good();
	CWE126_Buffer_Overread__CWE129_fgets_32_good();
	CWE126_Buffer_Overread__CWE129_fgets_34_good();
	CWE126_Buffer_Overread__CWE129_fgets_41_good();
	CWE126_Buffer_Overread__CWE129_fgets_42_good();
	CWE126_Buffer_Overread__CWE129_fgets_44_good();
	CWE126_Buffer_Overread__CWE129_fgets_45_good();
	CWE126_Buffer_Overread__CWE129_fgets_51_good();
	CWE126_Buffer_Overread__CWE129_fgets_52_good();
	CWE126_Buffer_Overread__CWE129_fgets_53_good();
	CWE126_Buffer_Overread__CWE129_fgets_54_good();
	CWE126_Buffer_Overread__CWE129_fgets_61_good();
	CWE126_Buffer_Overread__CWE129_fgets_63_good();
	CWE126_Buffer_Overread__CWE129_fgets_64_good();
	CWE126_Buffer_Overread__CWE129_fgets_65_good();
	CWE126_Buffer_Overread__CWE129_fgets_66_good();
	CWE126_Buffer_Overread__CWE129_fgets_67_good();
	CWE126_Buffer_Overread__CWE129_fgets_68_good();

	CWE126_Buffer_Overread__CWE129_fgets_01_bad();
	CWE126_Buffer_Overread__CWE129_fgets_02_bad();
	CWE126_Buffer_Overread__CWE129_fgets_03_bad();
	CWE126_Buffer_Overread__CWE129_fgets_04_bad();
	CWE126_Buffer_Overread__CWE129_fgets_05_bad();
	CWE126_Buffer_Overread__CWE129_fgets_06_bad();
	CWE126_Buffer_Overread__CWE129_fgets_07_bad();
	CWE126_Buffer_Overread__CWE129_fgets_08_bad();
	CWE126_Buffer_Overread__CWE129_fgets_09_bad();
	CWE126_Buffer_Overread__CWE129_fgets_10_bad();
	CWE126_Buffer_Overread__CWE129_fgets_11_bad();
	CWE126_Buffer_Overread__CWE129_fgets_12_bad();
	CWE126_Buffer_Overread__CWE129_fgets_13_bad();
	CWE126_Buffer_Overread__CWE129_fgets_14_bad();
	CWE126_Buffer_Overread__CWE129_fgets_15_bad();
	CWE126_Buffer_Overread__CWE129_fgets_16_bad();
	CWE126_Buffer_Overread__CWE129_fgets_17_bad();
	CWE126_Buffer_Overread__CWE129_fgets_18_bad();
	CWE126_Buffer_Overread__CWE129_fgets_21_bad();
	CWE126_Buffer_Overread__CWE129_fgets_22_bad();
	CWE126_Buffer_Overread__CWE129_fgets_31_bad();
	CWE126_Buffer_Overread__CWE129_fgets_32_bad();
	CWE126_Buffer_Overread__CWE129_fgets_34_bad();
	CWE126_Buffer_Overread__CWE129_fgets_41_bad();
	CWE126_Buffer_Overread__CWE129_fgets_42_bad();
	CWE126_Buffer_Overread__CWE129_fgets_44_bad();
	CWE126_Buffer_Overread__CWE129_fgets_45_bad();
	CWE126_Buffer_Overread__CWE129_fgets_51_bad();
	CWE126_Buffer_Overread__CWE129_fgets_52_bad();
	CWE126_Buffer_Overread__CWE129_fgets_53_bad();
	CWE126_Buffer_Overread__CWE129_fgets_54_bad();
	CWE126_Buffer_Overread__CWE129_fgets_61_bad();
	CWE126_Buffer_Overread__CWE129_fgets_63_bad();
	CWE126_Buffer_Overread__CWE129_fgets_64_bad();
	CWE126_Buffer_Overread__CWE129_fgets_65_bad();
	CWE126_Buffer_Overread__CWE129_fgets_66_bad();
	CWE126_Buffer_Overread__CWE129_fgets_67_bad();
	CWE126_Buffer_Overread__CWE129_fgets_68_bad();

	return 0;
}
