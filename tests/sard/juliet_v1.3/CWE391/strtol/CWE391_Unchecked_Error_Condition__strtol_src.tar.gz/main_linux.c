#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE391_Unchecked_Error_Condition__strtol_01_good();
	CWE391_Unchecked_Error_Condition__strtol_02_good();
	CWE391_Unchecked_Error_Condition__strtol_03_good();
	CWE391_Unchecked_Error_Condition__strtol_04_good();
	CWE391_Unchecked_Error_Condition__strtol_05_good();
	CWE391_Unchecked_Error_Condition__strtol_06_good();
	CWE391_Unchecked_Error_Condition__strtol_07_good();
	CWE391_Unchecked_Error_Condition__strtol_08_good();
	CWE391_Unchecked_Error_Condition__strtol_09_good();
	CWE391_Unchecked_Error_Condition__strtol_10_good();
	CWE391_Unchecked_Error_Condition__strtol_11_good();
	CWE391_Unchecked_Error_Condition__strtol_12_good();
	CWE391_Unchecked_Error_Condition__strtol_13_good();
	CWE391_Unchecked_Error_Condition__strtol_14_good();
	CWE391_Unchecked_Error_Condition__strtol_15_good();
	CWE391_Unchecked_Error_Condition__strtol_16_good();
	CWE391_Unchecked_Error_Condition__strtol_17_good();
	CWE391_Unchecked_Error_Condition__strtol_18_good();

	CWE391_Unchecked_Error_Condition__strtol_01_bad();
	CWE391_Unchecked_Error_Condition__strtol_02_bad();
	CWE391_Unchecked_Error_Condition__strtol_03_bad();
	CWE391_Unchecked_Error_Condition__strtol_04_bad();
	CWE391_Unchecked_Error_Condition__strtol_05_bad();
	CWE391_Unchecked_Error_Condition__strtol_06_bad();
	CWE391_Unchecked_Error_Condition__strtol_07_bad();
	CWE391_Unchecked_Error_Condition__strtol_08_bad();
	CWE391_Unchecked_Error_Condition__strtol_09_bad();
	CWE391_Unchecked_Error_Condition__strtol_10_bad();
	CWE391_Unchecked_Error_Condition__strtol_11_bad();
	CWE391_Unchecked_Error_Condition__strtol_12_bad();
	CWE391_Unchecked_Error_Condition__strtol_13_bad();
	CWE391_Unchecked_Error_Condition__strtol_14_bad();
	CWE391_Unchecked_Error_Condition__strtol_15_bad();
	CWE391_Unchecked_Error_Condition__strtol_16_bad();
	CWE391_Unchecked_Error_Condition__strtol_17_bad();
	CWE391_Unchecked_Error_Condition__strtol_18_bad();

	return 0;
}
