#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE129_large_01_good();
	CWE126_Buffer_Overread__CWE129_large_02_good();
	CWE126_Buffer_Overread__CWE129_large_03_good();
	CWE126_Buffer_Overread__CWE129_large_04_good();
	CWE126_Buffer_Overread__CWE129_large_05_good();
	CWE126_Buffer_Overread__CWE129_large_06_good();
	CWE126_Buffer_Overread__CWE129_large_07_good();
	CWE126_Buffer_Overread__CWE129_large_08_good();
	CWE126_Buffer_Overread__CWE129_large_09_good();
	CWE126_Buffer_Overread__CWE129_large_10_good();
	CWE126_Buffer_Overread__CWE129_large_11_good();
	CWE126_Buffer_Overread__CWE129_large_12_good();
	CWE126_Buffer_Overread__CWE129_large_13_good();
	CWE126_Buffer_Overread__CWE129_large_14_good();
	CWE126_Buffer_Overread__CWE129_large_15_good();
	CWE126_Buffer_Overread__CWE129_large_16_good();
	CWE126_Buffer_Overread__CWE129_large_17_good();
	CWE126_Buffer_Overread__CWE129_large_18_good();
	CWE126_Buffer_Overread__CWE129_large_21_good();
	CWE126_Buffer_Overread__CWE129_large_22_good();
	CWE126_Buffer_Overread__CWE129_large_31_good();
	CWE126_Buffer_Overread__CWE129_large_32_good();
	CWE126_Buffer_Overread__CWE129_large_34_good();
	CWE126_Buffer_Overread__CWE129_large_41_good();
	CWE126_Buffer_Overread__CWE129_large_42_good();
	CWE126_Buffer_Overread__CWE129_large_44_good();
	CWE126_Buffer_Overread__CWE129_large_45_good();
	CWE126_Buffer_Overread__CWE129_large_51_good();
	CWE126_Buffer_Overread__CWE129_large_52_good();
	CWE126_Buffer_Overread__CWE129_large_53_good();
	CWE126_Buffer_Overread__CWE129_large_54_good();
	CWE126_Buffer_Overread__CWE129_large_61_good();
	CWE126_Buffer_Overread__CWE129_large_63_good();
	CWE126_Buffer_Overread__CWE129_large_64_good();
	CWE126_Buffer_Overread__CWE129_large_65_good();
	CWE126_Buffer_Overread__CWE129_large_66_good();
	CWE126_Buffer_Overread__CWE129_large_67_good();
	CWE126_Buffer_Overread__CWE129_large_68_good();

	CWE126_Buffer_Overread__CWE129_large_01_bad();
	CWE126_Buffer_Overread__CWE129_large_02_bad();
	CWE126_Buffer_Overread__CWE129_large_03_bad();
	CWE126_Buffer_Overread__CWE129_large_04_bad();
	CWE126_Buffer_Overread__CWE129_large_05_bad();
	CWE126_Buffer_Overread__CWE129_large_06_bad();
	CWE126_Buffer_Overread__CWE129_large_07_bad();
	CWE126_Buffer_Overread__CWE129_large_08_bad();
	CWE126_Buffer_Overread__CWE129_large_09_bad();
	CWE126_Buffer_Overread__CWE129_large_10_bad();
	CWE126_Buffer_Overread__CWE129_large_11_bad();
	CWE126_Buffer_Overread__CWE129_large_12_bad();
	CWE126_Buffer_Overread__CWE129_large_13_bad();
	CWE126_Buffer_Overread__CWE129_large_14_bad();
	CWE126_Buffer_Overread__CWE129_large_15_bad();
	CWE126_Buffer_Overread__CWE129_large_16_bad();
	CWE126_Buffer_Overread__CWE129_large_17_bad();
	CWE126_Buffer_Overread__CWE129_large_18_bad();
	CWE126_Buffer_Overread__CWE129_large_21_bad();
	CWE126_Buffer_Overread__CWE129_large_22_bad();
	CWE126_Buffer_Overread__CWE129_large_31_bad();
	CWE126_Buffer_Overread__CWE129_large_32_bad();
	CWE126_Buffer_Overread__CWE129_large_34_bad();
	CWE126_Buffer_Overread__CWE129_large_41_bad();
	CWE126_Buffer_Overread__CWE129_large_42_bad();
	CWE126_Buffer_Overread__CWE129_large_44_bad();
	CWE126_Buffer_Overread__CWE129_large_45_bad();
	CWE126_Buffer_Overread__CWE129_large_51_bad();
	CWE126_Buffer_Overread__CWE129_large_52_bad();
	CWE126_Buffer_Overread__CWE129_large_53_bad();
	CWE126_Buffer_Overread__CWE129_large_54_bad();
	CWE126_Buffer_Overread__CWE129_large_61_bad();
	CWE126_Buffer_Overread__CWE129_large_63_bad();
	CWE126_Buffer_Overread__CWE129_large_64_bad();
	CWE126_Buffer_Overread__CWE129_large_65_bad();
	CWE126_Buffer_Overread__CWE129_large_66_bad();
	CWE126_Buffer_Overread__CWE129_large_67_bad();
	CWE126_Buffer_Overread__CWE129_large_68_bad();

	return 0;
}
