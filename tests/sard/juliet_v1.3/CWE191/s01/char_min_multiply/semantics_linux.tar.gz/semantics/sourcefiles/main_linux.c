#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE191_Integer_Underflow__char_min_multiply_01_good();
	CWE191_Integer_Underflow__char_min_multiply_02_good();
	CWE191_Integer_Underflow__char_min_multiply_03_good();
	CWE191_Integer_Underflow__char_min_multiply_04_good();
	CWE191_Integer_Underflow__char_min_multiply_05_good();
	CWE191_Integer_Underflow__char_min_multiply_06_good();
	CWE191_Integer_Underflow__char_min_multiply_07_good();
	CWE191_Integer_Underflow__char_min_multiply_08_good();
	CWE191_Integer_Underflow__char_min_multiply_09_good();
	CWE191_Integer_Underflow__char_min_multiply_10_good();
	CWE191_Integer_Underflow__char_min_multiply_11_good();
	CWE191_Integer_Underflow__char_min_multiply_12_good();
	CWE191_Integer_Underflow__char_min_multiply_13_good();
	CWE191_Integer_Underflow__char_min_multiply_14_good();
	CWE191_Integer_Underflow__char_min_multiply_15_good();
	CWE191_Integer_Underflow__char_min_multiply_16_good();
	CWE191_Integer_Underflow__char_min_multiply_17_good();
	CWE191_Integer_Underflow__char_min_multiply_18_good();
	CWE191_Integer_Underflow__char_min_multiply_21_good();
	CWE191_Integer_Underflow__char_min_multiply_22_good();
	CWE191_Integer_Underflow__char_min_multiply_31_good();
	CWE191_Integer_Underflow__char_min_multiply_32_good();
	CWE191_Integer_Underflow__char_min_multiply_34_good();
	CWE191_Integer_Underflow__char_min_multiply_41_good();
	CWE191_Integer_Underflow__char_min_multiply_42_good();
	CWE191_Integer_Underflow__char_min_multiply_44_good();
	CWE191_Integer_Underflow__char_min_multiply_45_good();
	CWE191_Integer_Underflow__char_min_multiply_51_good();
	CWE191_Integer_Underflow__char_min_multiply_52_good();
	CWE191_Integer_Underflow__char_min_multiply_53_good();
	CWE191_Integer_Underflow__char_min_multiply_54_good();
	CWE191_Integer_Underflow__char_min_multiply_61_good();
	CWE191_Integer_Underflow__char_min_multiply_63_good();
	CWE191_Integer_Underflow__char_min_multiply_64_good();
	CWE191_Integer_Underflow__char_min_multiply_65_good();
	CWE191_Integer_Underflow__char_min_multiply_66_good();
	CWE191_Integer_Underflow__char_min_multiply_67_good();
	CWE191_Integer_Underflow__char_min_multiply_68_good();

	CWE191_Integer_Underflow__char_min_multiply_01_bad();
	CWE191_Integer_Underflow__char_min_multiply_02_bad();
	CWE191_Integer_Underflow__char_min_multiply_03_bad();
	CWE191_Integer_Underflow__char_min_multiply_04_bad();
	CWE191_Integer_Underflow__char_min_multiply_05_bad();
	CWE191_Integer_Underflow__char_min_multiply_06_bad();
	CWE191_Integer_Underflow__char_min_multiply_07_bad();
	CWE191_Integer_Underflow__char_min_multiply_08_bad();
	CWE191_Integer_Underflow__char_min_multiply_09_bad();
	CWE191_Integer_Underflow__char_min_multiply_10_bad();
	CWE191_Integer_Underflow__char_min_multiply_11_bad();
	CWE191_Integer_Underflow__char_min_multiply_12_bad();
	CWE191_Integer_Underflow__char_min_multiply_13_bad();
	CWE191_Integer_Underflow__char_min_multiply_14_bad();
	CWE191_Integer_Underflow__char_min_multiply_15_bad();
	CWE191_Integer_Underflow__char_min_multiply_16_bad();
	CWE191_Integer_Underflow__char_min_multiply_17_bad();
	CWE191_Integer_Underflow__char_min_multiply_18_bad();
	CWE191_Integer_Underflow__char_min_multiply_21_bad();
	CWE191_Integer_Underflow__char_min_multiply_22_bad();
	CWE191_Integer_Underflow__char_min_multiply_31_bad();
	CWE191_Integer_Underflow__char_min_multiply_32_bad();
	CWE191_Integer_Underflow__char_min_multiply_34_bad();
	CWE191_Integer_Underflow__char_min_multiply_41_bad();
	CWE191_Integer_Underflow__char_min_multiply_42_bad();
	CWE191_Integer_Underflow__char_min_multiply_44_bad();
	CWE191_Integer_Underflow__char_min_multiply_45_bad();
	CWE191_Integer_Underflow__char_min_multiply_51_bad();
	CWE191_Integer_Underflow__char_min_multiply_52_bad();
	CWE191_Integer_Underflow__char_min_multiply_53_bad();
	CWE191_Integer_Underflow__char_min_multiply_54_bad();
	CWE191_Integer_Underflow__char_min_multiply_61_bad();
	CWE191_Integer_Underflow__char_min_multiply_63_bad();
	CWE191_Integer_Underflow__char_min_multiply_64_bad();
	CWE191_Integer_Underflow__char_min_multiply_65_bad();
	CWE191_Integer_Underflow__char_min_multiply_66_bad();
	CWE191_Integer_Underflow__char_min_multiply_67_bad();
	CWE191_Integer_Underflow__char_min_multiply_68_bad();

	return 0;
}
