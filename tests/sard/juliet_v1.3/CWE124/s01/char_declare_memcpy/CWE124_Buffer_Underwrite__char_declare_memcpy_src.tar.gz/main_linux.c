#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE124_Buffer_Underwrite__char_declare_memcpy_01_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_02_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_03_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_04_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_05_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_06_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_07_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_08_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_09_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_10_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_11_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_12_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_13_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_14_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_15_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_16_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_17_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_18_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_31_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_32_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_34_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_41_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_44_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_45_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_51_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_52_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_53_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_54_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_63_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_64_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_65_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_66_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_67_good();
	CWE124_Buffer_Underwrite__char_declare_memcpy_68_good();

	CWE124_Buffer_Underwrite__char_declare_memcpy_01_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_02_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_03_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_04_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_05_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_06_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_07_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_08_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_09_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_10_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_11_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_12_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_13_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_14_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_15_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_16_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_17_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_18_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_31_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_32_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_34_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_41_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_44_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_45_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_51_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_52_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_53_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_54_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_63_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_64_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_65_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_66_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_67_bad();
	CWE124_Buffer_Underwrite__char_declare_memcpy_68_bad();

	return 0;
}
