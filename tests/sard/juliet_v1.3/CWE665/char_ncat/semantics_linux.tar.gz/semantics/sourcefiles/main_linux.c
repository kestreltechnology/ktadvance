#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE665_Improper_Initialization__char_ncat_01_good();
	CWE665_Improper_Initialization__char_ncat_02_good();
	CWE665_Improper_Initialization__char_ncat_03_good();
	CWE665_Improper_Initialization__char_ncat_04_good();
	CWE665_Improper_Initialization__char_ncat_05_good();
	CWE665_Improper_Initialization__char_ncat_06_good();
	CWE665_Improper_Initialization__char_ncat_07_good();
	CWE665_Improper_Initialization__char_ncat_08_good();
	CWE665_Improper_Initialization__char_ncat_09_good();
	CWE665_Improper_Initialization__char_ncat_10_good();
	CWE665_Improper_Initialization__char_ncat_11_good();
	CWE665_Improper_Initialization__char_ncat_12_good();
	CWE665_Improper_Initialization__char_ncat_13_good();
	CWE665_Improper_Initialization__char_ncat_14_good();
	CWE665_Improper_Initialization__char_ncat_15_good();
	CWE665_Improper_Initialization__char_ncat_16_good();
	CWE665_Improper_Initialization__char_ncat_17_good();
	CWE665_Improper_Initialization__char_ncat_18_good();
	CWE665_Improper_Initialization__char_ncat_21_good();
	CWE665_Improper_Initialization__char_ncat_22_good();
	CWE665_Improper_Initialization__char_ncat_31_good();
	CWE665_Improper_Initialization__char_ncat_32_good();
	CWE665_Improper_Initialization__char_ncat_34_good();
	CWE665_Improper_Initialization__char_ncat_41_good();
	CWE665_Improper_Initialization__char_ncat_42_good();
	CWE665_Improper_Initialization__char_ncat_44_good();
	CWE665_Improper_Initialization__char_ncat_45_good();
	CWE665_Improper_Initialization__char_ncat_51_good();
	CWE665_Improper_Initialization__char_ncat_52_good();
	CWE665_Improper_Initialization__char_ncat_53_good();
	CWE665_Improper_Initialization__char_ncat_54_good();
	CWE665_Improper_Initialization__char_ncat_61_good();
	CWE665_Improper_Initialization__char_ncat_63_good();
	CWE665_Improper_Initialization__char_ncat_64_good();
	CWE665_Improper_Initialization__char_ncat_65_good();
	CWE665_Improper_Initialization__char_ncat_66_good();
	CWE665_Improper_Initialization__char_ncat_67_good();
	CWE665_Improper_Initialization__char_ncat_68_good();

	CWE665_Improper_Initialization__char_ncat_01_bad();
	CWE665_Improper_Initialization__char_ncat_02_bad();
	CWE665_Improper_Initialization__char_ncat_03_bad();
	CWE665_Improper_Initialization__char_ncat_04_bad();
	CWE665_Improper_Initialization__char_ncat_05_bad();
	CWE665_Improper_Initialization__char_ncat_06_bad();
	CWE665_Improper_Initialization__char_ncat_07_bad();
	CWE665_Improper_Initialization__char_ncat_08_bad();
	CWE665_Improper_Initialization__char_ncat_09_bad();
	CWE665_Improper_Initialization__char_ncat_10_bad();
	CWE665_Improper_Initialization__char_ncat_11_bad();
	CWE665_Improper_Initialization__char_ncat_12_bad();
	CWE665_Improper_Initialization__char_ncat_13_bad();
	CWE665_Improper_Initialization__char_ncat_14_bad();
	CWE665_Improper_Initialization__char_ncat_15_bad();
	CWE665_Improper_Initialization__char_ncat_16_bad();
	CWE665_Improper_Initialization__char_ncat_17_bad();
	CWE665_Improper_Initialization__char_ncat_18_bad();
	CWE665_Improper_Initialization__char_ncat_21_bad();
	CWE665_Improper_Initialization__char_ncat_22_bad();
	CWE665_Improper_Initialization__char_ncat_31_bad();
	CWE665_Improper_Initialization__char_ncat_32_bad();
	CWE665_Improper_Initialization__char_ncat_34_bad();
	CWE665_Improper_Initialization__char_ncat_41_bad();
	CWE665_Improper_Initialization__char_ncat_42_bad();
	CWE665_Improper_Initialization__char_ncat_44_bad();
	CWE665_Improper_Initialization__char_ncat_45_bad();
	CWE665_Improper_Initialization__char_ncat_51_bad();
	CWE665_Improper_Initialization__char_ncat_52_bad();
	CWE665_Improper_Initialization__char_ncat_53_bad();
	CWE665_Improper_Initialization__char_ncat_54_bad();
	CWE665_Improper_Initialization__char_ncat_61_bad();
	CWE665_Improper_Initialization__char_ncat_63_bad();
	CWE665_Improper_Initialization__char_ncat_64_bad();
	CWE665_Improper_Initialization__char_ncat_65_bad();
	CWE665_Improper_Initialization__char_ncat_66_bad();
	CWE665_Improper_Initialization__char_ncat_67_bad();
	CWE665_Improper_Initialization__char_ncat_68_bad();

	return 0;
}
