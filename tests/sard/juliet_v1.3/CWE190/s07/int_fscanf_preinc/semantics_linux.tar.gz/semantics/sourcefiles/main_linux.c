#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE190_Integer_Overflow__int_fscanf_preinc_01_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_02_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_03_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_04_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_05_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_06_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_07_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_08_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_09_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_10_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_11_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_12_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_13_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_14_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_15_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_16_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_17_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_18_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_21_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_22_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_31_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_32_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_34_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_41_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_42_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_44_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_45_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_51_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_52_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_53_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_54_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_61_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_63_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_64_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_65_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_66_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_67_good();
	CWE190_Integer_Overflow__int_fscanf_preinc_68_good();

	CWE190_Integer_Overflow__int_fscanf_preinc_01_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_02_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_03_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_04_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_05_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_06_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_07_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_08_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_09_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_10_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_11_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_12_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_13_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_14_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_15_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_16_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_17_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_18_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_21_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_22_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_31_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_32_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_34_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_41_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_42_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_44_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_45_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_51_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_52_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_53_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_54_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_61_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_63_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_64_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_65_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_66_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_67_bad();
	CWE190_Integer_Overflow__int_fscanf_preinc_68_bad();

	return 0;
}
