#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE129_connect_socket_01_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_02_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_03_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_04_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_05_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_06_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_07_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_08_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_09_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_10_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_11_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_12_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_13_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_14_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_15_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_16_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_17_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_18_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_21_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_22_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_31_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_32_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_34_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_41_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_42_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_44_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_45_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_51_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_52_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_53_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_54_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_61_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_63_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_64_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_65_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_66_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_67_good();
	CWE126_Buffer_Overread__CWE129_connect_socket_68_good();

	CWE126_Buffer_Overread__CWE129_connect_socket_01_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_02_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_03_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_04_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_05_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_06_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_07_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_08_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_09_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_10_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_11_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_12_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_13_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_14_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_15_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_16_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_17_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_18_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_21_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_22_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_31_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_32_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_34_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_41_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_42_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_44_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_45_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_51_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_52_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_53_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_54_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_61_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_63_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_64_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_65_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_66_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_67_bad();
	CWE126_Buffer_Overread__CWE129_connect_socket_68_bad();

	return 0;
}
