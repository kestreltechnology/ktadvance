#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__return_freed_ptr_01_good();
	CWE416_Use_After_Free__return_freed_ptr_02_good();
	CWE416_Use_After_Free__return_freed_ptr_03_good();
	CWE416_Use_After_Free__return_freed_ptr_04_good();
	CWE416_Use_After_Free__return_freed_ptr_05_good();
	CWE416_Use_After_Free__return_freed_ptr_06_good();
	CWE416_Use_After_Free__return_freed_ptr_07_good();
	CWE416_Use_After_Free__return_freed_ptr_08_good();
	CWE416_Use_After_Free__return_freed_ptr_09_good();
	CWE416_Use_After_Free__return_freed_ptr_10_good();
	CWE416_Use_After_Free__return_freed_ptr_11_good();
	CWE416_Use_After_Free__return_freed_ptr_12_good();
	CWE416_Use_After_Free__return_freed_ptr_13_good();
	CWE416_Use_After_Free__return_freed_ptr_14_good();
	CWE416_Use_After_Free__return_freed_ptr_15_good();
	CWE416_Use_After_Free__return_freed_ptr_16_good();
	CWE416_Use_After_Free__return_freed_ptr_17_good();
	CWE416_Use_After_Free__return_freed_ptr_18_good();

	CWE416_Use_After_Free__return_freed_ptr_01_bad();
	CWE416_Use_After_Free__return_freed_ptr_02_bad();
	CWE416_Use_After_Free__return_freed_ptr_03_bad();
	CWE416_Use_After_Free__return_freed_ptr_04_bad();
	CWE416_Use_After_Free__return_freed_ptr_05_bad();
	CWE416_Use_After_Free__return_freed_ptr_06_bad();
	CWE416_Use_After_Free__return_freed_ptr_07_bad();
	CWE416_Use_After_Free__return_freed_ptr_08_bad();
	CWE416_Use_After_Free__return_freed_ptr_09_bad();
	CWE416_Use_After_Free__return_freed_ptr_10_bad();
	CWE416_Use_After_Free__return_freed_ptr_11_bad();
	CWE416_Use_After_Free__return_freed_ptr_12_bad();
	CWE416_Use_After_Free__return_freed_ptr_13_bad();
	CWE416_Use_After_Free__return_freed_ptr_14_bad();
	CWE416_Use_After_Free__return_freed_ptr_15_bad();
	CWE416_Use_After_Free__return_freed_ptr_16_bad();
	CWE416_Use_After_Free__return_freed_ptr_17_bad();
	CWE416_Use_After_Free__return_freed_ptr_18_bad();

	return 0;
}
