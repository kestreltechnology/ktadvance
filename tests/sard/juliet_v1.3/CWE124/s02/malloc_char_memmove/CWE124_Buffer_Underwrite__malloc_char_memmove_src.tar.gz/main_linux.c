#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE124_Buffer_Underwrite__malloc_char_memmove_01_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_02_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_03_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_04_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_05_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_06_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_07_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_08_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_09_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_10_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_11_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_12_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_13_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_14_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_15_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_16_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_17_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_18_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_21_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_22_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_31_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_32_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_34_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_41_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_42_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_44_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_45_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_51_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_52_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_53_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_54_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_61_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_63_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_64_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_65_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_66_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_67_good();
	CWE124_Buffer_Underwrite__malloc_char_memmove_68_good();

	CWE124_Buffer_Underwrite__malloc_char_memmove_01_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_02_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_03_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_04_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_05_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_06_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_07_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_08_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_09_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_10_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_11_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_12_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_13_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_14_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_15_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_16_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_17_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_18_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_21_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_22_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_31_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_32_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_34_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_41_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_42_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_44_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_45_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_51_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_52_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_53_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_54_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_61_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_63_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_64_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_65_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_66_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_67_bad();
	CWE124_Buffer_Underwrite__malloc_char_memmove_68_bad();

	return 0;
}
