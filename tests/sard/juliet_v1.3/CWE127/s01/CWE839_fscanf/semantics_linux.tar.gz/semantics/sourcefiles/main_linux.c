#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE127_Buffer_Underread__CWE839_fscanf_01_good();
	CWE127_Buffer_Underread__CWE839_fscanf_02_good();
	CWE127_Buffer_Underread__CWE839_fscanf_03_good();
	CWE127_Buffer_Underread__CWE839_fscanf_04_good();
	CWE127_Buffer_Underread__CWE839_fscanf_05_good();
	CWE127_Buffer_Underread__CWE839_fscanf_06_good();
	CWE127_Buffer_Underread__CWE839_fscanf_07_good();
	CWE127_Buffer_Underread__CWE839_fscanf_08_good();
	CWE127_Buffer_Underread__CWE839_fscanf_09_good();
	CWE127_Buffer_Underread__CWE839_fscanf_10_good();
	CWE127_Buffer_Underread__CWE839_fscanf_11_good();
	CWE127_Buffer_Underread__CWE839_fscanf_12_good();
	CWE127_Buffer_Underread__CWE839_fscanf_13_good();
	CWE127_Buffer_Underread__CWE839_fscanf_14_good();
	CWE127_Buffer_Underread__CWE839_fscanf_15_good();
	CWE127_Buffer_Underread__CWE839_fscanf_16_good();
	CWE127_Buffer_Underread__CWE839_fscanf_17_good();
	CWE127_Buffer_Underread__CWE839_fscanf_18_good();
	CWE127_Buffer_Underread__CWE839_fscanf_21_good();
	CWE127_Buffer_Underread__CWE839_fscanf_22_good();
	CWE127_Buffer_Underread__CWE839_fscanf_31_good();
	CWE127_Buffer_Underread__CWE839_fscanf_32_good();
	CWE127_Buffer_Underread__CWE839_fscanf_34_good();
	CWE127_Buffer_Underread__CWE839_fscanf_41_good();
	CWE127_Buffer_Underread__CWE839_fscanf_42_good();
	CWE127_Buffer_Underread__CWE839_fscanf_44_good();
	CWE127_Buffer_Underread__CWE839_fscanf_45_good();
	CWE127_Buffer_Underread__CWE839_fscanf_51_good();
	CWE127_Buffer_Underread__CWE839_fscanf_52_good();
	CWE127_Buffer_Underread__CWE839_fscanf_53_good();
	CWE127_Buffer_Underread__CWE839_fscanf_54_good();
	CWE127_Buffer_Underread__CWE839_fscanf_61_good();
	CWE127_Buffer_Underread__CWE839_fscanf_63_good();
	CWE127_Buffer_Underread__CWE839_fscanf_64_good();
	CWE127_Buffer_Underread__CWE839_fscanf_65_good();
	CWE127_Buffer_Underread__CWE839_fscanf_66_good();
	CWE127_Buffer_Underread__CWE839_fscanf_67_good();
	CWE127_Buffer_Underread__CWE839_fscanf_68_good();

	CWE127_Buffer_Underread__CWE839_fscanf_01_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_02_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_03_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_04_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_05_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_06_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_07_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_08_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_09_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_10_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_11_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_12_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_13_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_14_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_15_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_16_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_17_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_18_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_21_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_22_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_31_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_32_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_34_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_41_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_42_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_44_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_45_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_51_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_52_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_53_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_54_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_61_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_63_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_64_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_65_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_66_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_67_bad();
	CWE127_Buffer_Underread__CWE839_fscanf_68_bad();

	return 0;
}
