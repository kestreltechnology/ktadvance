#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE369_Divide_by_Zero__float_listenSocket_01_good();
	CWE369_Divide_by_Zero__float_listenSocket_02_good();
	CWE369_Divide_by_Zero__float_listenSocket_03_good();
	CWE369_Divide_by_Zero__float_listenSocket_04_good();
	CWE369_Divide_by_Zero__float_listenSocket_05_good();
	CWE369_Divide_by_Zero__float_listenSocket_06_good();
	CWE369_Divide_by_Zero__float_listenSocket_07_good();
	CWE369_Divide_by_Zero__float_listenSocket_08_good();
	CWE369_Divide_by_Zero__float_listenSocket_09_good();
	CWE369_Divide_by_Zero__float_listenSocket_10_good();
	CWE369_Divide_by_Zero__float_listenSocket_11_good();
	CWE369_Divide_by_Zero__float_listenSocket_12_good();
	CWE369_Divide_by_Zero__float_listenSocket_13_good();
	CWE369_Divide_by_Zero__float_listenSocket_14_good();
	CWE369_Divide_by_Zero__float_listenSocket_15_good();
	CWE369_Divide_by_Zero__float_listenSocket_16_good();
	CWE369_Divide_by_Zero__float_listenSocket_17_good();
	CWE369_Divide_by_Zero__float_listenSocket_18_good();
	CWE369_Divide_by_Zero__float_listenSocket_21_good();
	CWE369_Divide_by_Zero__float_listenSocket_22_good();
	CWE369_Divide_by_Zero__float_listenSocket_31_good();
	CWE369_Divide_by_Zero__float_listenSocket_32_good();
	CWE369_Divide_by_Zero__float_listenSocket_34_good();
	CWE369_Divide_by_Zero__float_listenSocket_41_good();
	CWE369_Divide_by_Zero__float_listenSocket_42_good();
	CWE369_Divide_by_Zero__float_listenSocket_44_good();
	CWE369_Divide_by_Zero__float_listenSocket_45_good();
	CWE369_Divide_by_Zero__float_listenSocket_51_good();
	CWE369_Divide_by_Zero__float_listenSocket_52_good();
	CWE369_Divide_by_Zero__float_listenSocket_53_good();
	CWE369_Divide_by_Zero__float_listenSocket_54_good();
	CWE369_Divide_by_Zero__float_listenSocket_61_good();
	CWE369_Divide_by_Zero__float_listenSocket_63_good();
	CWE369_Divide_by_Zero__float_listenSocket_64_good();
	CWE369_Divide_by_Zero__float_listenSocket_65_good();
	CWE369_Divide_by_Zero__float_listenSocket_66_good();
	CWE369_Divide_by_Zero__float_listenSocket_67_good();
	CWE369_Divide_by_Zero__float_listenSocket_68_good();

	CWE369_Divide_by_Zero__float_listenSocket_01_bad();
	CWE369_Divide_by_Zero__float_listenSocket_02_bad();
	CWE369_Divide_by_Zero__float_listenSocket_03_bad();
	CWE369_Divide_by_Zero__float_listenSocket_04_bad();
	CWE369_Divide_by_Zero__float_listenSocket_05_bad();
	CWE369_Divide_by_Zero__float_listenSocket_06_bad();
	CWE369_Divide_by_Zero__float_listenSocket_07_bad();
	CWE369_Divide_by_Zero__float_listenSocket_08_bad();
	CWE369_Divide_by_Zero__float_listenSocket_09_bad();
	CWE369_Divide_by_Zero__float_listenSocket_10_bad();
	CWE369_Divide_by_Zero__float_listenSocket_11_bad();
	CWE369_Divide_by_Zero__float_listenSocket_12_bad();
	CWE369_Divide_by_Zero__float_listenSocket_13_bad();
	CWE369_Divide_by_Zero__float_listenSocket_14_bad();
	CWE369_Divide_by_Zero__float_listenSocket_15_bad();
	CWE369_Divide_by_Zero__float_listenSocket_16_bad();
	CWE369_Divide_by_Zero__float_listenSocket_17_bad();
	CWE369_Divide_by_Zero__float_listenSocket_18_bad();
	CWE369_Divide_by_Zero__float_listenSocket_21_bad();
	CWE369_Divide_by_Zero__float_listenSocket_22_bad();
	CWE369_Divide_by_Zero__float_listenSocket_31_bad();
	CWE369_Divide_by_Zero__float_listenSocket_32_bad();
	CWE369_Divide_by_Zero__float_listenSocket_34_bad();
	CWE369_Divide_by_Zero__float_listenSocket_41_bad();
	CWE369_Divide_by_Zero__float_listenSocket_42_bad();
	CWE369_Divide_by_Zero__float_listenSocket_44_bad();
	CWE369_Divide_by_Zero__float_listenSocket_45_bad();
	CWE369_Divide_by_Zero__float_listenSocket_51_bad();
	CWE369_Divide_by_Zero__float_listenSocket_52_bad();
	CWE369_Divide_by_Zero__float_listenSocket_53_bad();
	CWE369_Divide_by_Zero__float_listenSocket_54_bad();
	CWE369_Divide_by_Zero__float_listenSocket_61_bad();
	CWE369_Divide_by_Zero__float_listenSocket_63_bad();
	CWE369_Divide_by_Zero__float_listenSocket_64_bad();
	CWE369_Divide_by_Zero__float_listenSocket_65_bad();
	CWE369_Divide_by_Zero__float_listenSocket_66_bad();
	CWE369_Divide_by_Zero__float_listenSocket_67_bad();
	CWE369_Divide_by_Zero__float_listenSocket_68_bad();

	return 0;
}
