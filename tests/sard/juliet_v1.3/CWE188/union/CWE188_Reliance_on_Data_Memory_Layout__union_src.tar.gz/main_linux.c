#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE188_Reliance_on_Data_Memory_Layout__union_01_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_02_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_03_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_04_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_05_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_06_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_07_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_08_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_09_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_10_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_11_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_12_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_13_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_14_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_15_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_16_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_17_good();
	CWE188_Reliance_on_Data_Memory_Layout__union_18_good();

	CWE188_Reliance_on_Data_Memory_Layout__union_01_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_02_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_03_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_04_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_05_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_06_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_07_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_08_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_09_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_10_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_11_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_12_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_13_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_14_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_15_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_16_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_17_bad();
	CWE188_Reliance_on_Data_Memory_Layout__union_18_bad();

	return 0;
}
