#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE467_Use_of_sizeof_on_Pointer_Type__char_01_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_02_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_03_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_04_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_05_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_06_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_07_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_08_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_09_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_10_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_11_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_12_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_13_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_14_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_15_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_16_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_17_good();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_18_good();

	CWE467_Use_of_sizeof_on_Pointer_Type__char_01_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_02_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_03_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_04_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_05_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_06_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_07_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_08_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_09_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_10_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_11_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_12_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_13_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_14_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_15_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_16_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_17_bad();
	CWE467_Use_of_sizeof_on_Pointer_Type__char_18_bad();

	return 0;
}
