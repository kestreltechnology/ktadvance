#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE188_Reliance_on_Data_Memory_Layout__modify_local_01_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_02_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_03_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_04_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_05_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_06_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_07_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_08_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_09_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_10_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_11_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_12_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_13_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_14_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_15_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_16_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_17_good();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_18_good();

	CWE188_Reliance_on_Data_Memory_Layout__modify_local_01_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_02_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_03_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_04_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_05_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_06_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_07_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_08_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_09_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_10_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_11_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_12_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_13_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_14_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_15_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_16_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_17_bad();
	CWE188_Reliance_on_Data_Memory_Layout__modify_local_18_bad();

	return 0;
}
