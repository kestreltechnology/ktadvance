#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE127_Buffer_Underread__CWE839_negative_01_good();
	CWE127_Buffer_Underread__CWE839_negative_02_good();
	CWE127_Buffer_Underread__CWE839_negative_03_good();
	CWE127_Buffer_Underread__CWE839_negative_04_good();
	CWE127_Buffer_Underread__CWE839_negative_05_good();
	CWE127_Buffer_Underread__CWE839_negative_06_good();
	CWE127_Buffer_Underread__CWE839_negative_07_good();
	CWE127_Buffer_Underread__CWE839_negative_08_good();
	CWE127_Buffer_Underread__CWE839_negative_09_good();
	CWE127_Buffer_Underread__CWE839_negative_10_good();
	CWE127_Buffer_Underread__CWE839_negative_11_good();
	CWE127_Buffer_Underread__CWE839_negative_12_good();
	CWE127_Buffer_Underread__CWE839_negative_13_good();
	CWE127_Buffer_Underread__CWE839_negative_14_good();
	CWE127_Buffer_Underread__CWE839_negative_15_good();
	CWE127_Buffer_Underread__CWE839_negative_16_good();
	CWE127_Buffer_Underread__CWE839_negative_17_good();
	CWE127_Buffer_Underread__CWE839_negative_18_good();
	CWE127_Buffer_Underread__CWE839_negative_21_good();
	CWE127_Buffer_Underread__CWE839_negative_22_good();
	CWE127_Buffer_Underread__CWE839_negative_31_good();
	CWE127_Buffer_Underread__CWE839_negative_32_good();
	CWE127_Buffer_Underread__CWE839_negative_34_good();
	CWE127_Buffer_Underread__CWE839_negative_41_good();
	CWE127_Buffer_Underread__CWE839_negative_42_good();
	CWE127_Buffer_Underread__CWE839_negative_44_good();
	CWE127_Buffer_Underread__CWE839_negative_45_good();
	CWE127_Buffer_Underread__CWE839_negative_51_good();
	CWE127_Buffer_Underread__CWE839_negative_52_good();
	CWE127_Buffer_Underread__CWE839_negative_53_good();
	CWE127_Buffer_Underread__CWE839_negative_54_good();
	CWE127_Buffer_Underread__CWE839_negative_61_good();
	CWE127_Buffer_Underread__CWE839_negative_63_good();
	CWE127_Buffer_Underread__CWE839_negative_64_good();
	CWE127_Buffer_Underread__CWE839_negative_65_good();
	CWE127_Buffer_Underread__CWE839_negative_66_good();
	CWE127_Buffer_Underread__CWE839_negative_67_good();
	CWE127_Buffer_Underread__CWE839_negative_68_good();

	CWE127_Buffer_Underread__CWE839_negative_01_bad();
	CWE127_Buffer_Underread__CWE839_negative_02_bad();
	CWE127_Buffer_Underread__CWE839_negative_03_bad();
	CWE127_Buffer_Underread__CWE839_negative_04_bad();
	CWE127_Buffer_Underread__CWE839_negative_05_bad();
	CWE127_Buffer_Underread__CWE839_negative_06_bad();
	CWE127_Buffer_Underread__CWE839_negative_07_bad();
	CWE127_Buffer_Underread__CWE839_negative_08_bad();
	CWE127_Buffer_Underread__CWE839_negative_09_bad();
	CWE127_Buffer_Underread__CWE839_negative_10_bad();
	CWE127_Buffer_Underread__CWE839_negative_11_bad();
	CWE127_Buffer_Underread__CWE839_negative_12_bad();
	CWE127_Buffer_Underread__CWE839_negative_13_bad();
	CWE127_Buffer_Underread__CWE839_negative_14_bad();
	CWE127_Buffer_Underread__CWE839_negative_15_bad();
	CWE127_Buffer_Underread__CWE839_negative_16_bad();
	CWE127_Buffer_Underread__CWE839_negative_17_bad();
	CWE127_Buffer_Underread__CWE839_negative_18_bad();
	CWE127_Buffer_Underread__CWE839_negative_21_bad();
	CWE127_Buffer_Underread__CWE839_negative_22_bad();
	CWE127_Buffer_Underread__CWE839_negative_31_bad();
	CWE127_Buffer_Underread__CWE839_negative_32_bad();
	CWE127_Buffer_Underread__CWE839_negative_34_bad();
	CWE127_Buffer_Underread__CWE839_negative_41_bad();
	CWE127_Buffer_Underread__CWE839_negative_42_bad();
	CWE127_Buffer_Underread__CWE839_negative_44_bad();
	CWE127_Buffer_Underread__CWE839_negative_45_bad();
	CWE127_Buffer_Underread__CWE839_negative_51_bad();
	CWE127_Buffer_Underread__CWE839_negative_52_bad();
	CWE127_Buffer_Underread__CWE839_negative_53_bad();
	CWE127_Buffer_Underread__CWE839_negative_54_bad();
	CWE127_Buffer_Underread__CWE839_negative_61_bad();
	CWE127_Buffer_Underread__CWE839_negative_63_bad();
	CWE127_Buffer_Underread__CWE839_negative_64_bad();
	CWE127_Buffer_Underread__CWE839_negative_65_bad();
	CWE127_Buffer_Underread__CWE839_negative_66_bad();
	CWE127_Buffer_Underread__CWE839_negative_67_bad();
	CWE127_Buffer_Underread__CWE839_negative_68_bad();

	return 0;
}
