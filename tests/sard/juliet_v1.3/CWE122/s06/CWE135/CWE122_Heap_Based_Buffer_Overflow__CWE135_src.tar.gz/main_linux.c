#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE122_Heap_Based_Buffer_Overflow__CWE135_01_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_02_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_03_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_04_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_05_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_06_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_07_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_08_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_09_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_10_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_11_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_12_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_13_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_14_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_15_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_16_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_17_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_18_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_21_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_22_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_31_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_32_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_34_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_41_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_42_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_44_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_45_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_51_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_52_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_53_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_54_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_61_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_63_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_64_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_65_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_66_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_67_good();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_68_good();

	CWE122_Heap_Based_Buffer_Overflow__CWE135_01_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_02_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_03_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_04_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_05_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_06_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_07_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_08_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_09_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_10_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_11_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_12_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_13_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_14_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_15_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_16_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_17_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_18_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_21_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_22_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_31_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_32_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_34_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_41_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_42_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_44_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_45_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_51_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_52_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_53_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_54_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_61_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_63_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_64_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_65_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_66_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_67_bad();
	CWE122_Heap_Based_Buffer_Overflow__CWE135_68_bad();

	return 0;
}
