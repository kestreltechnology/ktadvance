#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE129_fscanf_01_good();
	CWE126_Buffer_Overread__CWE129_fscanf_02_good();
	CWE126_Buffer_Overread__CWE129_fscanf_03_good();
	CWE126_Buffer_Overread__CWE129_fscanf_04_good();
	CWE126_Buffer_Overread__CWE129_fscanf_05_good();
	CWE126_Buffer_Overread__CWE129_fscanf_06_good();
	CWE126_Buffer_Overread__CWE129_fscanf_07_good();
	CWE126_Buffer_Overread__CWE129_fscanf_08_good();
	CWE126_Buffer_Overread__CWE129_fscanf_09_good();
	CWE126_Buffer_Overread__CWE129_fscanf_10_good();
	CWE126_Buffer_Overread__CWE129_fscanf_11_good();
	CWE126_Buffer_Overread__CWE129_fscanf_12_good();
	CWE126_Buffer_Overread__CWE129_fscanf_13_good();
	CWE126_Buffer_Overread__CWE129_fscanf_14_good();
	CWE126_Buffer_Overread__CWE129_fscanf_15_good();
	CWE126_Buffer_Overread__CWE129_fscanf_16_good();
	CWE126_Buffer_Overread__CWE129_fscanf_17_good();
	CWE126_Buffer_Overread__CWE129_fscanf_18_good();
	CWE126_Buffer_Overread__CWE129_fscanf_21_good();
	CWE126_Buffer_Overread__CWE129_fscanf_22_good();
	CWE126_Buffer_Overread__CWE129_fscanf_31_good();
	CWE126_Buffer_Overread__CWE129_fscanf_32_good();
	CWE126_Buffer_Overread__CWE129_fscanf_34_good();
	CWE126_Buffer_Overread__CWE129_fscanf_41_good();
	CWE126_Buffer_Overread__CWE129_fscanf_42_good();
	CWE126_Buffer_Overread__CWE129_fscanf_44_good();
	CWE126_Buffer_Overread__CWE129_fscanf_45_good();
	CWE126_Buffer_Overread__CWE129_fscanf_51_good();
	CWE126_Buffer_Overread__CWE129_fscanf_52_good();
	CWE126_Buffer_Overread__CWE129_fscanf_53_good();
	CWE126_Buffer_Overread__CWE129_fscanf_54_good();
	CWE126_Buffer_Overread__CWE129_fscanf_61_good();
	CWE126_Buffer_Overread__CWE129_fscanf_63_good();
	CWE126_Buffer_Overread__CWE129_fscanf_64_good();
	CWE126_Buffer_Overread__CWE129_fscanf_65_good();
	CWE126_Buffer_Overread__CWE129_fscanf_66_good();
	CWE126_Buffer_Overread__CWE129_fscanf_67_good();
	CWE126_Buffer_Overread__CWE129_fscanf_68_good();

	CWE126_Buffer_Overread__CWE129_fscanf_01_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_02_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_03_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_04_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_05_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_06_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_07_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_08_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_09_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_10_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_11_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_12_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_13_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_14_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_15_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_16_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_17_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_18_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_21_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_22_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_31_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_32_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_34_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_41_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_42_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_44_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_45_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_51_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_52_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_53_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_54_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_61_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_63_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_64_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_65_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_66_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_67_bad();
	CWE126_Buffer_Overread__CWE129_fscanf_68_bad();

	return 0;
}
