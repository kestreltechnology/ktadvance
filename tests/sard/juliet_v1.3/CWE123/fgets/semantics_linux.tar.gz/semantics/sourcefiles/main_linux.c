#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE123_Write_What_Where_Condition__fgets_01_good();
	CWE123_Write_What_Where_Condition__fgets_02_good();
	CWE123_Write_What_Where_Condition__fgets_03_good();
	CWE123_Write_What_Where_Condition__fgets_04_good();
	CWE123_Write_What_Where_Condition__fgets_05_good();
	CWE123_Write_What_Where_Condition__fgets_06_good();
	CWE123_Write_What_Where_Condition__fgets_07_good();
	CWE123_Write_What_Where_Condition__fgets_08_good();
	CWE123_Write_What_Where_Condition__fgets_09_good();
	CWE123_Write_What_Where_Condition__fgets_10_good();
	CWE123_Write_What_Where_Condition__fgets_11_good();
	CWE123_Write_What_Where_Condition__fgets_12_good();
	CWE123_Write_What_Where_Condition__fgets_13_good();
	CWE123_Write_What_Where_Condition__fgets_14_good();
	CWE123_Write_What_Where_Condition__fgets_15_good();
	CWE123_Write_What_Where_Condition__fgets_16_good();
	CWE123_Write_What_Where_Condition__fgets_17_good();
	CWE123_Write_What_Where_Condition__fgets_18_good();
	CWE123_Write_What_Where_Condition__fgets_21_good();
	CWE123_Write_What_Where_Condition__fgets_22_good();
	CWE123_Write_What_Where_Condition__fgets_31_good();
	CWE123_Write_What_Where_Condition__fgets_32_good();
	CWE123_Write_What_Where_Condition__fgets_34_good();
	CWE123_Write_What_Where_Condition__fgets_41_good();
	CWE123_Write_What_Where_Condition__fgets_42_good();
	CWE123_Write_What_Where_Condition__fgets_44_good();
	CWE123_Write_What_Where_Condition__fgets_45_good();
	CWE123_Write_What_Where_Condition__fgets_51_good();
	CWE123_Write_What_Where_Condition__fgets_52_good();
	CWE123_Write_What_Where_Condition__fgets_53_good();
	CWE123_Write_What_Where_Condition__fgets_54_good();
	CWE123_Write_What_Where_Condition__fgets_61_good();
	CWE123_Write_What_Where_Condition__fgets_63_good();
	CWE123_Write_What_Where_Condition__fgets_64_good();
	CWE123_Write_What_Where_Condition__fgets_65_good();
	CWE123_Write_What_Where_Condition__fgets_66_good();
	CWE123_Write_What_Where_Condition__fgets_67_good();
	CWE123_Write_What_Where_Condition__fgets_68_good();

	CWE123_Write_What_Where_Condition__fgets_01_bad();
	CWE123_Write_What_Where_Condition__fgets_02_bad();
	CWE123_Write_What_Where_Condition__fgets_03_bad();
	CWE123_Write_What_Where_Condition__fgets_04_bad();
	CWE123_Write_What_Where_Condition__fgets_05_bad();
	CWE123_Write_What_Where_Condition__fgets_06_bad();
	CWE123_Write_What_Where_Condition__fgets_07_bad();
	CWE123_Write_What_Where_Condition__fgets_08_bad();
	CWE123_Write_What_Where_Condition__fgets_09_bad();
	CWE123_Write_What_Where_Condition__fgets_10_bad();
	CWE123_Write_What_Where_Condition__fgets_11_bad();
	CWE123_Write_What_Where_Condition__fgets_12_bad();
	CWE123_Write_What_Where_Condition__fgets_13_bad();
	CWE123_Write_What_Where_Condition__fgets_14_bad();
	CWE123_Write_What_Where_Condition__fgets_15_bad();
	CWE123_Write_What_Where_Condition__fgets_16_bad();
	CWE123_Write_What_Where_Condition__fgets_17_bad();
	CWE123_Write_What_Where_Condition__fgets_18_bad();
	CWE123_Write_What_Where_Condition__fgets_21_bad();
	CWE123_Write_What_Where_Condition__fgets_22_bad();
	CWE123_Write_What_Where_Condition__fgets_31_bad();
	CWE123_Write_What_Where_Condition__fgets_32_bad();
	CWE123_Write_What_Where_Condition__fgets_34_bad();
	CWE123_Write_What_Where_Condition__fgets_41_bad();
	CWE123_Write_What_Where_Condition__fgets_42_bad();
	CWE123_Write_What_Where_Condition__fgets_44_bad();
	CWE123_Write_What_Where_Condition__fgets_45_bad();
	CWE123_Write_What_Where_Condition__fgets_51_bad();
	CWE123_Write_What_Where_Condition__fgets_52_bad();
	CWE123_Write_What_Where_Condition__fgets_53_bad();
	CWE123_Write_What_Where_Condition__fgets_54_bad();
	CWE123_Write_What_Where_Condition__fgets_61_bad();
	CWE123_Write_What_Where_Condition__fgets_63_bad();
	CWE123_Write_What_Where_Condition__fgets_64_bad();
	CWE123_Write_What_Where_Condition__fgets_65_bad();
	CWE123_Write_What_Where_Condition__fgets_66_bad();
	CWE123_Write_What_Where_Condition__fgets_67_bad();
	CWE123_Write_What_Where_Condition__fgets_68_bad();

	return 0;
}
