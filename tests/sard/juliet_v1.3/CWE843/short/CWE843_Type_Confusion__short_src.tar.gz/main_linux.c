#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE843_Type_Confusion__short_01_good();
	CWE843_Type_Confusion__short_02_good();
	CWE843_Type_Confusion__short_03_good();
	CWE843_Type_Confusion__short_04_good();
	CWE843_Type_Confusion__short_05_good();
	CWE843_Type_Confusion__short_06_good();
	CWE843_Type_Confusion__short_07_good();
	CWE843_Type_Confusion__short_08_good();
	CWE843_Type_Confusion__short_09_good();
	CWE843_Type_Confusion__short_10_good();
	CWE843_Type_Confusion__short_11_good();
	CWE843_Type_Confusion__short_12_good();
	CWE843_Type_Confusion__short_13_good();
	CWE843_Type_Confusion__short_14_good();
	CWE843_Type_Confusion__short_15_good();
	CWE843_Type_Confusion__short_16_good();
	CWE843_Type_Confusion__short_17_good();
	CWE843_Type_Confusion__short_18_good();
	CWE843_Type_Confusion__short_31_good();
	CWE843_Type_Confusion__short_32_good();
	CWE843_Type_Confusion__short_34_good();
	CWE843_Type_Confusion__short_41_good();
	CWE843_Type_Confusion__short_44_good();
	CWE843_Type_Confusion__short_45_good();
	CWE843_Type_Confusion__short_51_good();
	CWE843_Type_Confusion__short_52_good();
	CWE843_Type_Confusion__short_53_good();
	CWE843_Type_Confusion__short_54_good();
	CWE843_Type_Confusion__short_63_good();
	CWE843_Type_Confusion__short_64_good();
	CWE843_Type_Confusion__short_65_good();
	CWE843_Type_Confusion__short_66_good();
	CWE843_Type_Confusion__short_67_good();
	CWE843_Type_Confusion__short_68_good();

	CWE843_Type_Confusion__short_01_bad();
	CWE843_Type_Confusion__short_02_bad();
	CWE843_Type_Confusion__short_03_bad();
	CWE843_Type_Confusion__short_04_bad();
	CWE843_Type_Confusion__short_05_bad();
	CWE843_Type_Confusion__short_06_bad();
	CWE843_Type_Confusion__short_07_bad();
	CWE843_Type_Confusion__short_08_bad();
	CWE843_Type_Confusion__short_09_bad();
	CWE843_Type_Confusion__short_10_bad();
	CWE843_Type_Confusion__short_11_bad();
	CWE843_Type_Confusion__short_12_bad();
	CWE843_Type_Confusion__short_13_bad();
	CWE843_Type_Confusion__short_14_bad();
	CWE843_Type_Confusion__short_15_bad();
	CWE843_Type_Confusion__short_16_bad();
	CWE843_Type_Confusion__short_17_bad();
	CWE843_Type_Confusion__short_18_bad();
	CWE843_Type_Confusion__short_31_bad();
	CWE843_Type_Confusion__short_32_bad();
	CWE843_Type_Confusion__short_34_bad();
	CWE843_Type_Confusion__short_41_bad();
	CWE843_Type_Confusion__short_44_bad();
	CWE843_Type_Confusion__short_45_bad();
	CWE843_Type_Confusion__short_51_bad();
	CWE843_Type_Confusion__short_52_bad();
	CWE843_Type_Confusion__short_53_bad();
	CWE843_Type_Confusion__short_54_bad();
	CWE843_Type_Confusion__short_63_bad();
	CWE843_Type_Confusion__short_64_bad();
	CWE843_Type_Confusion__short_65_bad();
	CWE843_Type_Confusion__short_66_bad();
	CWE843_Type_Confusion__short_67_bad();
	CWE843_Type_Confusion__short_68_bad();

	return 0;
}
