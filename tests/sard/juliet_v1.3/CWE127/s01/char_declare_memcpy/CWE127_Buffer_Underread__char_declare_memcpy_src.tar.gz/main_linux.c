#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE127_Buffer_Underread__char_declare_memcpy_01_good();
	CWE127_Buffer_Underread__char_declare_memcpy_02_good();
	CWE127_Buffer_Underread__char_declare_memcpy_03_good();
	CWE127_Buffer_Underread__char_declare_memcpy_04_good();
	CWE127_Buffer_Underread__char_declare_memcpy_05_good();
	CWE127_Buffer_Underread__char_declare_memcpy_06_good();
	CWE127_Buffer_Underread__char_declare_memcpy_07_good();
	CWE127_Buffer_Underread__char_declare_memcpy_08_good();
	CWE127_Buffer_Underread__char_declare_memcpy_09_good();
	CWE127_Buffer_Underread__char_declare_memcpy_10_good();
	CWE127_Buffer_Underread__char_declare_memcpy_11_good();
	CWE127_Buffer_Underread__char_declare_memcpy_12_good();
	CWE127_Buffer_Underread__char_declare_memcpy_13_good();
	CWE127_Buffer_Underread__char_declare_memcpy_14_good();
	CWE127_Buffer_Underread__char_declare_memcpy_15_good();
	CWE127_Buffer_Underread__char_declare_memcpy_16_good();
	CWE127_Buffer_Underread__char_declare_memcpy_17_good();
	CWE127_Buffer_Underread__char_declare_memcpy_18_good();
	CWE127_Buffer_Underread__char_declare_memcpy_31_good();
	CWE127_Buffer_Underread__char_declare_memcpy_32_good();
	CWE127_Buffer_Underread__char_declare_memcpy_34_good();
	CWE127_Buffer_Underread__char_declare_memcpy_41_good();
	CWE127_Buffer_Underread__char_declare_memcpy_44_good();
	CWE127_Buffer_Underread__char_declare_memcpy_45_good();
	CWE127_Buffer_Underread__char_declare_memcpy_51_good();
	CWE127_Buffer_Underread__char_declare_memcpy_52_good();
	CWE127_Buffer_Underread__char_declare_memcpy_53_good();
	CWE127_Buffer_Underread__char_declare_memcpy_54_good();
	CWE127_Buffer_Underread__char_declare_memcpy_63_good();
	CWE127_Buffer_Underread__char_declare_memcpy_64_good();
	CWE127_Buffer_Underread__char_declare_memcpy_65_good();
	CWE127_Buffer_Underread__char_declare_memcpy_66_good();
	CWE127_Buffer_Underread__char_declare_memcpy_67_good();
	CWE127_Buffer_Underread__char_declare_memcpy_68_good();

	CWE127_Buffer_Underread__char_declare_memcpy_01_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_02_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_03_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_04_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_05_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_06_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_07_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_08_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_09_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_10_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_11_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_12_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_13_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_14_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_15_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_16_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_17_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_18_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_31_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_32_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_34_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_41_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_44_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_45_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_51_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_52_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_53_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_54_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_63_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_64_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_65_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_66_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_67_bad();
	CWE127_Buffer_Underread__char_declare_memcpy_68_bad();

	return 0;
}
