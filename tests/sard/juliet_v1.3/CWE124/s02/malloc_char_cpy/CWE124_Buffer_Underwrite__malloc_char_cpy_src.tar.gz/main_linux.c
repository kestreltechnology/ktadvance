#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE124_Buffer_Underwrite__malloc_char_cpy_01_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_02_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_03_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_04_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_05_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_06_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_07_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_08_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_09_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_10_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_11_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_12_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_13_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_14_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_15_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_16_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_17_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_18_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_21_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_22_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_31_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_32_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_34_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_41_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_42_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_44_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_45_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_51_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_52_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_53_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_54_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_61_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_63_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_64_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_65_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_66_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_67_good();
	CWE124_Buffer_Underwrite__malloc_char_cpy_68_good();

	CWE124_Buffer_Underwrite__malloc_char_cpy_01_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_02_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_03_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_04_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_05_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_06_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_07_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_08_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_09_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_10_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_11_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_12_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_13_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_14_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_15_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_16_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_17_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_18_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_21_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_22_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_31_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_32_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_34_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_41_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_42_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_44_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_45_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_51_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_52_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_53_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_54_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_61_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_63_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_64_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_65_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_66_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_67_bad();
	CWE124_Buffer_Underwrite__malloc_char_cpy_68_bad();

	return 0;
}
