#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE416_Use_After_Free__malloc_free_int64_t_01_good();
	CWE416_Use_After_Free__malloc_free_int64_t_02_good();
	CWE416_Use_After_Free__malloc_free_int64_t_03_good();
	CWE416_Use_After_Free__malloc_free_int64_t_04_good();
	CWE416_Use_After_Free__malloc_free_int64_t_05_good();
	CWE416_Use_After_Free__malloc_free_int64_t_06_good();
	CWE416_Use_After_Free__malloc_free_int64_t_07_good();
	CWE416_Use_After_Free__malloc_free_int64_t_08_good();
	CWE416_Use_After_Free__malloc_free_int64_t_09_good();
	CWE416_Use_After_Free__malloc_free_int64_t_10_good();
	CWE416_Use_After_Free__malloc_free_int64_t_11_good();
	CWE416_Use_After_Free__malloc_free_int64_t_12_good();
	CWE416_Use_After_Free__malloc_free_int64_t_13_good();
	CWE416_Use_After_Free__malloc_free_int64_t_14_good();
	CWE416_Use_After_Free__malloc_free_int64_t_15_good();
	CWE416_Use_After_Free__malloc_free_int64_t_16_good();
	CWE416_Use_After_Free__malloc_free_int64_t_17_good();
	CWE416_Use_After_Free__malloc_free_int64_t_18_good();
	CWE416_Use_After_Free__malloc_free_int64_t_63_good();
	CWE416_Use_After_Free__malloc_free_int64_t_64_good();

	CWE416_Use_After_Free__malloc_free_int64_t_01_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_02_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_03_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_04_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_05_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_06_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_07_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_08_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_09_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_10_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_11_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_12_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_13_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_14_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_15_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_16_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_17_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_18_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_63_bad();
	CWE416_Use_After_Free__malloc_free_int64_t_64_bad();

	return 0;
}
