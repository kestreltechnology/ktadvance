#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE252_Unchecked_Return_Value__char_fgets_01_good();
	CWE252_Unchecked_Return_Value__char_fgets_02_good();
	CWE252_Unchecked_Return_Value__char_fgets_03_good();
	CWE252_Unchecked_Return_Value__char_fgets_04_good();
	CWE252_Unchecked_Return_Value__char_fgets_05_good();
	CWE252_Unchecked_Return_Value__char_fgets_06_good();
	CWE252_Unchecked_Return_Value__char_fgets_07_good();
	CWE252_Unchecked_Return_Value__char_fgets_08_good();
	CWE252_Unchecked_Return_Value__char_fgets_09_good();
	CWE252_Unchecked_Return_Value__char_fgets_10_good();
	CWE252_Unchecked_Return_Value__char_fgets_11_good();
	CWE252_Unchecked_Return_Value__char_fgets_12_good();
	CWE252_Unchecked_Return_Value__char_fgets_13_good();
	CWE252_Unchecked_Return_Value__char_fgets_14_good();
	CWE252_Unchecked_Return_Value__char_fgets_15_good();
	CWE252_Unchecked_Return_Value__char_fgets_16_good();
	CWE252_Unchecked_Return_Value__char_fgets_17_good();
	CWE252_Unchecked_Return_Value__char_fgets_18_good();

	CWE252_Unchecked_Return_Value__char_fgets_01_bad();
	CWE252_Unchecked_Return_Value__char_fgets_02_bad();
	CWE252_Unchecked_Return_Value__char_fgets_03_bad();
	CWE252_Unchecked_Return_Value__char_fgets_04_bad();
	CWE252_Unchecked_Return_Value__char_fgets_05_bad();
	CWE252_Unchecked_Return_Value__char_fgets_06_bad();
	CWE252_Unchecked_Return_Value__char_fgets_07_bad();
	CWE252_Unchecked_Return_Value__char_fgets_08_bad();
	CWE252_Unchecked_Return_Value__char_fgets_09_bad();
	CWE252_Unchecked_Return_Value__char_fgets_10_bad();
	CWE252_Unchecked_Return_Value__char_fgets_11_bad();
	CWE252_Unchecked_Return_Value__char_fgets_12_bad();
	CWE252_Unchecked_Return_Value__char_fgets_13_bad();
	CWE252_Unchecked_Return_Value__char_fgets_14_bad();
	CWE252_Unchecked_Return_Value__char_fgets_15_bad();
	CWE252_Unchecked_Return_Value__char_fgets_16_bad();
	CWE252_Unchecked_Return_Value__char_fgets_17_bad();
	CWE252_Unchecked_Return_Value__char_fgets_18_bad();

	return 0;
}
