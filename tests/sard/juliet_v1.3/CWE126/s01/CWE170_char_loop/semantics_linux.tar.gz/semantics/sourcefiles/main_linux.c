#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE170_char_loop_01_good();
	CWE126_Buffer_Overread__CWE170_char_loop_02_good();
	CWE126_Buffer_Overread__CWE170_char_loop_03_good();
	CWE126_Buffer_Overread__CWE170_char_loop_04_good();
	CWE126_Buffer_Overread__CWE170_char_loop_05_good();
	CWE126_Buffer_Overread__CWE170_char_loop_06_good();
	CWE126_Buffer_Overread__CWE170_char_loop_07_good();
	CWE126_Buffer_Overread__CWE170_char_loop_08_good();
	CWE126_Buffer_Overread__CWE170_char_loop_09_good();
	CWE126_Buffer_Overread__CWE170_char_loop_10_good();
	CWE126_Buffer_Overread__CWE170_char_loop_11_good();
	CWE126_Buffer_Overread__CWE170_char_loop_12_good();
	CWE126_Buffer_Overread__CWE170_char_loop_13_good();
	CWE126_Buffer_Overread__CWE170_char_loop_14_good();
	CWE126_Buffer_Overread__CWE170_char_loop_15_good();
	CWE126_Buffer_Overread__CWE170_char_loop_16_good();
	CWE126_Buffer_Overread__CWE170_char_loop_17_good();
	CWE126_Buffer_Overread__CWE170_char_loop_18_good();

	CWE126_Buffer_Overread__CWE170_char_loop_01_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_02_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_03_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_04_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_05_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_06_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_07_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_08_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_09_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_10_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_11_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_12_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_13_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_14_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_15_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_16_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_17_bad();
	CWE126_Buffer_Overread__CWE170_char_loop_18_bad();

	return 0;
}
