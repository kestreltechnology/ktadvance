#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE191_Integer_Underflow__char_fscanf_postdec_01_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_02_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_03_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_04_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_05_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_06_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_07_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_08_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_09_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_10_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_11_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_12_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_13_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_14_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_15_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_16_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_17_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_18_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_21_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_22_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_31_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_32_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_34_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_41_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_42_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_44_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_45_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_51_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_52_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_53_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_54_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_61_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_63_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_64_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_65_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_66_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_67_good();
	CWE191_Integer_Underflow__char_fscanf_postdec_68_good();

	CWE191_Integer_Underflow__char_fscanf_postdec_01_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_02_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_03_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_04_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_05_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_06_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_07_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_08_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_09_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_10_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_11_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_12_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_13_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_14_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_15_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_16_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_17_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_18_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_21_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_22_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_31_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_32_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_34_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_41_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_42_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_44_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_45_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_51_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_52_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_53_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_54_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_61_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_63_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_64_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_65_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_66_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_67_bad();
	CWE191_Integer_Underflow__char_fscanf_postdec_68_bad();

	return 0;
}
