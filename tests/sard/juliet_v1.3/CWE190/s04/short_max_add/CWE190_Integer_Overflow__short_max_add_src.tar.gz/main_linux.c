#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE190_Integer_Overflow__short_max_add_01_good();
	CWE190_Integer_Overflow__short_max_add_02_good();
	CWE190_Integer_Overflow__short_max_add_03_good();
	CWE190_Integer_Overflow__short_max_add_04_good();
	CWE190_Integer_Overflow__short_max_add_05_good();
	CWE190_Integer_Overflow__short_max_add_06_good();
	CWE190_Integer_Overflow__short_max_add_07_good();
	CWE190_Integer_Overflow__short_max_add_08_good();
	CWE190_Integer_Overflow__short_max_add_09_good();
	CWE190_Integer_Overflow__short_max_add_10_good();
	CWE190_Integer_Overflow__short_max_add_11_good();
	CWE190_Integer_Overflow__short_max_add_12_good();
	CWE190_Integer_Overflow__short_max_add_13_good();
	CWE190_Integer_Overflow__short_max_add_14_good();
	CWE190_Integer_Overflow__short_max_add_15_good();
	CWE190_Integer_Overflow__short_max_add_16_good();
	CWE190_Integer_Overflow__short_max_add_17_good();
	CWE190_Integer_Overflow__short_max_add_18_good();
	CWE190_Integer_Overflow__short_max_add_21_good();
	CWE190_Integer_Overflow__short_max_add_22_good();
	CWE190_Integer_Overflow__short_max_add_31_good();
	CWE190_Integer_Overflow__short_max_add_32_good();
	CWE190_Integer_Overflow__short_max_add_34_good();
	CWE190_Integer_Overflow__short_max_add_41_good();
	CWE190_Integer_Overflow__short_max_add_42_good();
	CWE190_Integer_Overflow__short_max_add_44_good();
	CWE190_Integer_Overflow__short_max_add_45_good();
	CWE190_Integer_Overflow__short_max_add_51_good();
	CWE190_Integer_Overflow__short_max_add_52_good();
	CWE190_Integer_Overflow__short_max_add_53_good();
	CWE190_Integer_Overflow__short_max_add_54_good();
	CWE190_Integer_Overflow__short_max_add_61_good();
	CWE190_Integer_Overflow__short_max_add_63_good();
	CWE190_Integer_Overflow__short_max_add_64_good();
	CWE190_Integer_Overflow__short_max_add_65_good();
	CWE190_Integer_Overflow__short_max_add_66_good();
	CWE190_Integer_Overflow__short_max_add_67_good();
	CWE190_Integer_Overflow__short_max_add_68_good();

	CWE190_Integer_Overflow__short_max_add_01_bad();
	CWE190_Integer_Overflow__short_max_add_02_bad();
	CWE190_Integer_Overflow__short_max_add_03_bad();
	CWE190_Integer_Overflow__short_max_add_04_bad();
	CWE190_Integer_Overflow__short_max_add_05_bad();
	CWE190_Integer_Overflow__short_max_add_06_bad();
	CWE190_Integer_Overflow__short_max_add_07_bad();
	CWE190_Integer_Overflow__short_max_add_08_bad();
	CWE190_Integer_Overflow__short_max_add_09_bad();
	CWE190_Integer_Overflow__short_max_add_10_bad();
	CWE190_Integer_Overflow__short_max_add_11_bad();
	CWE190_Integer_Overflow__short_max_add_12_bad();
	CWE190_Integer_Overflow__short_max_add_13_bad();
	CWE190_Integer_Overflow__short_max_add_14_bad();
	CWE190_Integer_Overflow__short_max_add_15_bad();
	CWE190_Integer_Overflow__short_max_add_16_bad();
	CWE190_Integer_Overflow__short_max_add_17_bad();
	CWE190_Integer_Overflow__short_max_add_18_bad();
	CWE190_Integer_Overflow__short_max_add_21_bad();
	CWE190_Integer_Overflow__short_max_add_22_bad();
	CWE190_Integer_Overflow__short_max_add_31_bad();
	CWE190_Integer_Overflow__short_max_add_32_bad();
	CWE190_Integer_Overflow__short_max_add_34_bad();
	CWE190_Integer_Overflow__short_max_add_41_bad();
	CWE190_Integer_Overflow__short_max_add_42_bad();
	CWE190_Integer_Overflow__short_max_add_44_bad();
	CWE190_Integer_Overflow__short_max_add_45_bad();
	CWE190_Integer_Overflow__short_max_add_51_bad();
	CWE190_Integer_Overflow__short_max_add_52_bad();
	CWE190_Integer_Overflow__short_max_add_53_bad();
	CWE190_Integer_Overflow__short_max_add_54_bad();
	CWE190_Integer_Overflow__short_max_add_61_bad();
	CWE190_Integer_Overflow__short_max_add_63_bad();
	CWE190_Integer_Overflow__short_max_add_64_bad();
	CWE190_Integer_Overflow__short_max_add_65_bad();
	CWE190_Integer_Overflow__short_max_add_66_bad();
	CWE190_Integer_Overflow__short_max_add_67_bad();
	CWE190_Integer_Overflow__short_max_add_68_bad();

	return 0;
}
