#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE196_Unsigned_to_Signed_Conversion_Error__basic_01_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_02_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_03_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_04_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_05_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_06_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_07_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_08_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_09_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_10_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_11_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_12_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_13_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_14_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_15_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_16_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_17_good();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_18_good();

	CWE196_Unsigned_to_Signed_Conversion_Error__basic_01_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_02_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_03_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_04_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_05_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_06_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_07_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_08_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_09_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_10_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_11_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_12_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_13_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_14_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_15_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_16_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_17_bad();
	CWE196_Unsigned_to_Signed_Conversion_Error__basic_18_bad();

	return 0;
}
