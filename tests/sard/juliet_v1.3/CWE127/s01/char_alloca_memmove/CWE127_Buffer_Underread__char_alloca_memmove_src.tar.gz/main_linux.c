#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE127_Buffer_Underread__char_alloca_memmove_01_good();
	CWE127_Buffer_Underread__char_alloca_memmove_02_good();
	CWE127_Buffer_Underread__char_alloca_memmove_03_good();
	CWE127_Buffer_Underread__char_alloca_memmove_04_good();
	CWE127_Buffer_Underread__char_alloca_memmove_05_good();
	CWE127_Buffer_Underread__char_alloca_memmove_06_good();
	CWE127_Buffer_Underread__char_alloca_memmove_07_good();
	CWE127_Buffer_Underread__char_alloca_memmove_08_good();
	CWE127_Buffer_Underread__char_alloca_memmove_09_good();
	CWE127_Buffer_Underread__char_alloca_memmove_10_good();
	CWE127_Buffer_Underread__char_alloca_memmove_11_good();
	CWE127_Buffer_Underread__char_alloca_memmove_12_good();
	CWE127_Buffer_Underread__char_alloca_memmove_13_good();
	CWE127_Buffer_Underread__char_alloca_memmove_14_good();
	CWE127_Buffer_Underread__char_alloca_memmove_15_good();
	CWE127_Buffer_Underread__char_alloca_memmove_16_good();
	CWE127_Buffer_Underread__char_alloca_memmove_17_good();
	CWE127_Buffer_Underread__char_alloca_memmove_18_good();
	CWE127_Buffer_Underread__char_alloca_memmove_31_good();
	CWE127_Buffer_Underread__char_alloca_memmove_32_good();
	CWE127_Buffer_Underread__char_alloca_memmove_34_good();
	CWE127_Buffer_Underread__char_alloca_memmove_41_good();
	CWE127_Buffer_Underread__char_alloca_memmove_44_good();
	CWE127_Buffer_Underread__char_alloca_memmove_45_good();
	CWE127_Buffer_Underread__char_alloca_memmove_51_good();
	CWE127_Buffer_Underread__char_alloca_memmove_52_good();
	CWE127_Buffer_Underread__char_alloca_memmove_53_good();
	CWE127_Buffer_Underread__char_alloca_memmove_54_good();
	CWE127_Buffer_Underread__char_alloca_memmove_63_good();
	CWE127_Buffer_Underread__char_alloca_memmove_64_good();
	CWE127_Buffer_Underread__char_alloca_memmove_65_good();
	CWE127_Buffer_Underread__char_alloca_memmove_66_good();
	CWE127_Buffer_Underread__char_alloca_memmove_67_good();
	CWE127_Buffer_Underread__char_alloca_memmove_68_good();

	CWE127_Buffer_Underread__char_alloca_memmove_01_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_02_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_03_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_04_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_05_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_06_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_07_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_08_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_09_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_10_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_11_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_12_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_13_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_14_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_15_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_16_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_17_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_18_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_31_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_32_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_34_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_41_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_44_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_45_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_51_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_52_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_53_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_54_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_63_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_64_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_65_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_66_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_67_bad();
	CWE127_Buffer_Underread__char_alloca_memmove_68_bad();

	return 0;
}
