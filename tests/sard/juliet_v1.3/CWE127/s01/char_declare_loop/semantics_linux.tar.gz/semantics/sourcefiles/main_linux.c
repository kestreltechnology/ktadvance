#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE127_Buffer_Underread__char_declare_loop_01_good();
	CWE127_Buffer_Underread__char_declare_loop_02_good();
	CWE127_Buffer_Underread__char_declare_loop_03_good();
	CWE127_Buffer_Underread__char_declare_loop_04_good();
	CWE127_Buffer_Underread__char_declare_loop_05_good();
	CWE127_Buffer_Underread__char_declare_loop_06_good();
	CWE127_Buffer_Underread__char_declare_loop_07_good();
	CWE127_Buffer_Underread__char_declare_loop_08_good();
	CWE127_Buffer_Underread__char_declare_loop_09_good();
	CWE127_Buffer_Underread__char_declare_loop_10_good();
	CWE127_Buffer_Underread__char_declare_loop_11_good();
	CWE127_Buffer_Underread__char_declare_loop_12_good();
	CWE127_Buffer_Underread__char_declare_loop_13_good();
	CWE127_Buffer_Underread__char_declare_loop_14_good();
	CWE127_Buffer_Underread__char_declare_loop_15_good();
	CWE127_Buffer_Underread__char_declare_loop_16_good();
	CWE127_Buffer_Underread__char_declare_loop_17_good();
	CWE127_Buffer_Underread__char_declare_loop_18_good();
	CWE127_Buffer_Underread__char_declare_loop_31_good();
	CWE127_Buffer_Underread__char_declare_loop_32_good();
	CWE127_Buffer_Underread__char_declare_loop_34_good();
	CWE127_Buffer_Underread__char_declare_loop_41_good();
	CWE127_Buffer_Underread__char_declare_loop_44_good();
	CWE127_Buffer_Underread__char_declare_loop_45_good();
	CWE127_Buffer_Underread__char_declare_loop_51_good();
	CWE127_Buffer_Underread__char_declare_loop_52_good();
	CWE127_Buffer_Underread__char_declare_loop_53_good();
	CWE127_Buffer_Underread__char_declare_loop_54_good();
	CWE127_Buffer_Underread__char_declare_loop_63_good();
	CWE127_Buffer_Underread__char_declare_loop_64_good();
	CWE127_Buffer_Underread__char_declare_loop_65_good();
	CWE127_Buffer_Underread__char_declare_loop_66_good();
	CWE127_Buffer_Underread__char_declare_loop_67_good();
	CWE127_Buffer_Underread__char_declare_loop_68_good();

	CWE127_Buffer_Underread__char_declare_loop_01_bad();
	CWE127_Buffer_Underread__char_declare_loop_02_bad();
	CWE127_Buffer_Underread__char_declare_loop_03_bad();
	CWE127_Buffer_Underread__char_declare_loop_04_bad();
	CWE127_Buffer_Underread__char_declare_loop_05_bad();
	CWE127_Buffer_Underread__char_declare_loop_06_bad();
	CWE127_Buffer_Underread__char_declare_loop_07_bad();
	CWE127_Buffer_Underread__char_declare_loop_08_bad();
	CWE127_Buffer_Underread__char_declare_loop_09_bad();
	CWE127_Buffer_Underread__char_declare_loop_10_bad();
	CWE127_Buffer_Underread__char_declare_loop_11_bad();
	CWE127_Buffer_Underread__char_declare_loop_12_bad();
	CWE127_Buffer_Underread__char_declare_loop_13_bad();
	CWE127_Buffer_Underread__char_declare_loop_14_bad();
	CWE127_Buffer_Underread__char_declare_loop_15_bad();
	CWE127_Buffer_Underread__char_declare_loop_16_bad();
	CWE127_Buffer_Underread__char_declare_loop_17_bad();
	CWE127_Buffer_Underread__char_declare_loop_18_bad();
	CWE127_Buffer_Underread__char_declare_loop_31_bad();
	CWE127_Buffer_Underread__char_declare_loop_32_bad();
	CWE127_Buffer_Underread__char_declare_loop_34_bad();
	CWE127_Buffer_Underread__char_declare_loop_41_bad();
	CWE127_Buffer_Underread__char_declare_loop_44_bad();
	CWE127_Buffer_Underread__char_declare_loop_45_bad();
	CWE127_Buffer_Underread__char_declare_loop_51_bad();
	CWE127_Buffer_Underread__char_declare_loop_52_bad();
	CWE127_Buffer_Underread__char_declare_loop_53_bad();
	CWE127_Buffer_Underread__char_declare_loop_54_bad();
	CWE127_Buffer_Underread__char_declare_loop_63_bad();
	CWE127_Buffer_Underread__char_declare_loop_64_bad();
	CWE127_Buffer_Underread__char_declare_loop_65_bad();
	CWE127_Buffer_Underread__char_declare_loop_66_bad();
	CWE127_Buffer_Underread__char_declare_loop_67_bad();
	CWE127_Buffer_Underread__char_declare_loop_68_bad();

	return 0;
}
