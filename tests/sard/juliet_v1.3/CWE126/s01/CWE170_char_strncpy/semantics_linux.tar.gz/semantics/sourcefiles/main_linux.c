#include <time.h>  
#include <stdlib.h>

#include "std_testcase.h"
#include "testcases.h"

int main(int argc, char * argv[]) {
  
	/* seed randomness */

	srand( (unsigned)time(NULL) );

	globalArgc = argc;
	globalArgv = argv;

	CWE126_Buffer_Overread__CWE170_char_strncpy_01_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_02_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_03_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_04_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_05_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_06_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_07_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_08_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_09_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_10_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_11_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_12_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_13_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_14_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_15_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_16_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_17_good();
	CWE126_Buffer_Overread__CWE170_char_strncpy_18_good();

	CWE126_Buffer_Overread__CWE170_char_strncpy_01_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_02_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_03_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_04_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_05_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_06_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_07_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_08_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_09_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_10_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_11_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_12_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_13_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_14_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_15_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_16_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_17_bad();
	CWE126_Buffer_Overread__CWE170_char_strncpy_18_bad();

	return 0;
}
